#define MyAppName "NovaDM"
#define MyAppVersion "1.0.0"

[Setup]
AppId={{8F3D2B1A-6C4E-4B8A-9F10-2D7E5A9C1B34}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher=NovaDM
DefaultDirName={autopf}\NovaDM
DefaultGroupName=NovaDM
OutputDir=installer_out
OutputBaseFilename=NovaDM-Setup
Compression=lzma2
SolidCompression=yes
PrivilegesRequired=lowest
SetupIconFile=app.ico
UninstallDisplayIcon={app}\NovaDM.exe
WizardStyle=modern
DisableProgramGroupPage=yes

[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; Flags: checkedonce
Name: "startup"; Description: "Start NovaDM with Windows (in the tray)"; Flags: unchecked

[Files]
Source: "dist\NovaDM.exe"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{group}\NovaDM"; Filename: "{app}\NovaDM.exe"
Name: "{autodesktop}\NovaDM"; Filename: "{app}\NovaDM.exe"; Tasks: desktopicon

[Registry]
Root: HKCU; Subkey: "Software\Microsoft\Windows\CurrentVersion\Run"; ValueType: string; ValueName: "NovaDM"; ValueData: """{app}\NovaDM.exe"" --tray"; Flags: uninsdeletevalue; Tasks: startup

[Run]
Filename: "{app}\NovaDM.exe"; Description: "Launch NovaDM"; Flags: nowait postinstall skipifsilent
