"""Creates app.ico from the code-drawn icon (run once; app.ico is already included)."""
from novadm.icon import draw_icon

draw_icon(256).save("app.ico", sizes=[(16, 16), (24, 24), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)])
