NovaDM - fast, free, ad-free download manager for Windows
=========================================================
Features: up to 32 connections per file with dynamic splitting, resume after restart/crash, queue + simultaneous
limit, speed limiter, scheduler (time window, start at, shut down/sleep when done), category folders, batch
patterns (site/img[01-50].jpg), login/referer/cookie support, clipboard link catcher, drag & drop links,
video + audio downloads from YouTube and 1000+ sites (yt-dlp), browser extension (Chrome/Edge/Brave/Firefox),
dark/light theme, system tray, start with Windows.

Build:  see build.yml (GitHub Actions, windows-latest) - produces NovaDM.exe and NovaDM-Setup.exe
Run from source:  pip install -r requirements.txt  &&  python main.py
