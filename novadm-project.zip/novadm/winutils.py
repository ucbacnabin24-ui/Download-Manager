"""Windows integration (all functions have harmless fallbacks on other systems)."""
import os
import subprocess
import sys
import webbrowser

IS_WIN = sys.platform.startswith("win")
NO_WINDOW = 0x08000000 if IS_WIN else 0


def open_path(path: str):
    try:
        if IS_WIN:
            os.startfile(path)  # noqa
        elif sys.platform == "darwin":
            subprocess.Popen(["open", path])
        else:
            subprocess.Popen(["xdg-open", path])
    except Exception:
        pass


def reveal(path: str):
    """Open Explorer with the file selected."""
    try:
        if IS_WIN and os.path.exists(path):
            subprocess.Popen(["explorer", "/select," + os.path.normpath(path)])
        else:
            open_path(os.path.dirname(path) if os.path.isfile(path) else path)
    except Exception:
        pass


def pick_folder(initial: str = ""):
    if not IS_WIN:
        return None
    init = (initial or "").replace("'", "''")
    script = (
        "[Console]::OutputEncoding = [System.Text.Encoding]::UTF8;"
        "Add-Type -AssemblyName System.Windows.Forms;"
        "$f = New-Object System.Windows.Forms.FolderBrowserDialog;"
        "$f.Description = 'Choose a folder';"
        "$f.ShowNewFolderButton = $true;"
        f"if ('{init}' -ne '' -and (Test-Path '{init}')) {{ $f.SelectedPath = '{init}' }};"
        "if ($f.ShowDialog() -eq 'OK') { Write-Output $f.SelectedPath }"
    )
    try:
        out = subprocess.run(["powershell", "-NoProfile", "-STA", "-WindowStyle", "Hidden", "-Command", script],
                             capture_output=True, creationflags=NO_WINDOW, timeout=600)
        txt = out.stdout.decode("utf-8", "replace").strip()
        return txt or None
    except Exception:
        return None


def clipboard_text() -> str:
    if not IS_WIN:
        return ""
    try:
        import ctypes
        u32, k32 = ctypes.windll.user32, ctypes.windll.kernel32
        u32.OpenClipboard.argtypes = [ctypes.c_void_p]
        u32.GetClipboardData.argtypes = [ctypes.c_uint]
        u32.GetClipboardData.restype = ctypes.c_void_p
        k32.GlobalLock.argtypes = [ctypes.c_void_p]
        k32.GlobalLock.restype = ctypes.c_void_p
        k32.GlobalUnlock.argtypes = [ctypes.c_void_p]
        if not u32.OpenClipboard(None):
            return ""
        try:
            h = u32.GetClipboardData(13)          # CF_UNICODETEXT
            if not h:
                return ""
            p = k32.GlobalLock(h)
            if not p:
                return ""
            try:
                return ctypes.wstring_at(p)
            finally:
                k32.GlobalUnlock(h)
        finally:
            u32.CloseClipboard()
    except Exception:
        return ""


def system_action(action: str):
    if not IS_WIN:
        return
    try:
        if action == "shutdown":
            subprocess.Popen(["shutdown", "/s", "/t", "60"], creationflags=NO_WINDOW)
        elif action == "sleep":
            subprocess.Popen(["rundll32.exe", "powrprof.dll,SetSuspendState", "0,1,0"], creationflags=NO_WINDOW)
    except Exception:
        pass


def cancel_shutdown():
    if IS_WIN:
        try:
            subprocess.Popen(["shutdown", "/a"], creationflags=NO_WINDOW)
        except Exception:
            pass


def set_startup(enabled: bool, name: str = "NovaDM"):
    if not IS_WIN or not getattr(sys, "frozen", False):
        return False
    try:
        import winreg
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Run", 0,
                             winreg.KEY_SET_VALUE)
        if enabled:
            winreg.SetValueEx(key, name, 0, winreg.REG_SZ, f'"{sys.executable}" --tray')
        else:
            try:
                winreg.DeleteValue(key, name)
            except FileNotFoundError:
                pass
        winreg.CloseKey(key)
        return True
    except Exception:
        return False


def find_browser():
    cands = []
    for env in ("ProgramFiles(x86)", "ProgramFiles", "LOCALAPPDATA"):
        base = os.environ.get(env)
        if base:
            cands.append(os.path.join(base, "Microsoft", "Edge", "Application", "msedge.exe"))
            cands.append(os.path.join(base, "Google", "Chrome", "Application", "chrome.exe"))
    for c in cands:
        if os.path.exists(c):
            return c
    return None


def open_app_window(url: str, profile_dir: str):
    """Open the UI as a chrome-less app window (Edge/Chrome --app). Falls back to the default browser."""
    exe = find_browser() if IS_WIN else None
    if exe:
        try:
            os.makedirs(profile_dir, exist_ok=True)
            subprocess.Popen([exe, f"--app={url}", f"--user-data-dir={profile_dir}", "--window-size=1240,780",
                              "--no-first-run", "--no-default-browser-check", "--disable-extensions"])
            return True
        except Exception:
            pass
    try:
        webbrowser.open(url)
    except Exception:
        pass
    return False
