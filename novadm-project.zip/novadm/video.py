"""Video downloads (YouTube and 1000+ sites) through yt-dlp, with optional ffmpeg."""
import os
import shutil
import sys
import time
import urllib.request
import zipfile

from .config import category_of, data_dir
from .engine import LIMITER, Download, UA, sanitize

HEIGHTS = (2160, 1440, 1080, 720, 480, 360, 240)
FFMPEG_URL = "https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip"


class _Quiet:
    def debug(self, m): pass
    def info(self, m): pass
    def warning(self, m): pass
    def error(self, m): pass


def have_ytdlp() -> bool:
    try:
        import yt_dlp  # noqa
        return True
    except Exception:
        return False


def ffmpeg_dir():
    exe = "ffmpeg.exe" if sys.platform.startswith("win") else "ffmpeg"
    local = os.path.join(data_dir(), "ffmpeg", exe)
    if os.path.exists(local):
        return os.path.dirname(local)
    w = shutil.which("ffmpeg")
    return os.path.dirname(w) if w else None


def install_ffmpeg(progress):
    """Download ffmpeg (Windows build) into the app data folder. progress(pct:int)."""
    dest_dir = os.path.join(data_dir(), "ffmpeg")
    os.makedirs(dest_dir, exist_ok=True)
    tmp = os.path.join(dest_dir, "ffmpeg.zip.part")
    req = urllib.request.Request(FFMPEG_URL, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=60) as r, open(tmp, "wb") as f:
        total = int(r.headers.get("Content-Length") or 0)
        done = 0
        while True:
            b = r.read(256 * 1024)
            if not b:
                break
            f.write(b)
            done += len(b)
            if total:
                progress(int(done * 90 / total))
    with zipfile.ZipFile(tmp) as z:
        for n in z.namelist():
            if n.lower().endswith("/bin/ffmpeg.exe") or n.lower().endswith("/bin/ffprobe.exe"):
                with z.open(n) as src, open(os.path.join(dest_dir, os.path.basename(n)), "wb") as out:
                    shutil.copyfileobj(src, out)
    os.remove(tmp)
    progress(100)


def video_info(url: str, cookie: str = "") -> dict:
    import yt_dlp
    opts = {"quiet": True, "no_warnings": True, "noplaylist": True, "skip_download": True, "logger": _Quiet(),
            "socket_timeout": 30}
    if cookie:
        opts["http_headers"] = {"Cookie": cookie}
    with yt_dlp.YoutubeDL(opts) as ydl:
        info = ydl.extract_info(url, download=False)
    if info.get("entries"):
        info = next((e for e in info["entries"] if e), info)
    top = 0
    for f in info.get("formats") or []:
        if f.get("height") and f.get("vcodec") not in (None, "none"):
            top = max(top, f["height"])
    options = [{"id": "best", "label": "Best available quality"}]
    for h in HEIGHTS:
        if h <= top:
            options.append({"id": str(h), "label": f"{h}p"})
    options.append({"id": "audio", "label": "Audio only (MP3)" if ffmpeg_dir() else "Audio only (best, original format)"})
    return {"title": info.get("title") or "video", "duration": info.get("duration") or 0,
            "uploader": info.get("uploader") or "", "thumbnail": info.get("thumbnail") or "",
            "options": options, "has_ffmpeg": bool(ffmpeg_dir())}


def format_for(choice: str, ff: bool):
    if choice == "audio":
        return "ba/b", True
    if choice in ("best", "", None):
        return ("bv*+ba/b" if ff else "b"), False
    h = int(choice)
    return (f"bv*[height<={h}]+ba/b[height<={h}]" if ff else f"b[height<={h}]/b"), False


class VideoDownload(Download):
    kind = "video"

    def __init__(self, url, folder, **opt):
        super().__init__(url, folder, **opt)
        self._base = 0
        self._cur = 0
        if not self.name:
            self.name = "Video (fetching info...)"
        self.cat = "Video" if self.vfmt != "audio" else "Music"
        self.resumable = True

    @property
    def downloaded(self):
        if self.status == "completed":
            return max(self.size, 0)
        return self._base + self._cur

    def delete_files(self):
        for p in (self.path, (self.path + ".part") if self.path else ""):
            if p:
                try:
                    os.remove(p)
                except OSError:
                    pass

    def _hook(self, d):
        from yt_dlp.utils import DownloadCancelled
        if self.stop_evt.is_set() or self.removed:
            raise DownloadCancelled()
        st = d.get("status")
        info = d.get("info_dict") or {}
        if info.get("title") and self.name.startswith("Video ("):
            self.name = sanitize(info["title"])
        if st == "downloading":
            self._cur = int(d.get("downloaded_bytes") or 0)
            tot = d.get("total_bytes") or d.get("total_bytes_estimate")
            if tot:
                self.size = max(self.size, int(tot) + self._base)
            sp = d.get("speed")
            if sp:
                self.speed = float(sp)
            if d.get("filename"):
                self.path = d["filename"]
        elif st == "finished":
            self._base += int(d.get("total_bytes") or self._cur or 0)
            self._cur = 0
            if d.get("filename"):
                self.path = d["filename"]

    def sample(self, now):
        if self.status != "downloading":
            self.speed = 0.0

    def _run(self):
        try:
            import yt_dlp
            from yt_dlp.utils import DownloadCancelled
        except Exception:
            self.error = "The video engine (yt-dlp) is not available in this build."
            self.status = "error"
            return
        self.last_try = time.time()
        try:
            ff = ffmpeg_dir()
            fmt, audio = format_for(self.vfmt, bool(ff))
            if self.auto_sort:
                self.folder = os.path.join(self.folder, "Music" if audio else "Video")
                self.auto_sort = False
            os.makedirs(self.folder, exist_ok=True)
            headers = {"User-Agent": self.ua or UA}
            if self.referer:
                headers["Referer"] = self.referer
            if self.cookie:
                headers["Cookie"] = self.cookie
            opts = {
                "outtmpl": os.path.join(self.folder, "%(title).150s.%(ext)s"),
                "noplaylist": True, "quiet": True, "no_warnings": True, "logger": _Quiet(),
                "progress_hooks": [self._hook], "continuedl": True, "retries": 10, "fragment_retries": 10,
                "concurrent_fragment_downloads": 4, "noprogress": True, "format": fmt, "http_headers": headers,
                "restrictfilenames": False, "windowsfilenames": True, "socket_timeout": 30,
            }
            if LIMITER.rate:
                opts["ratelimit"] = LIMITER.rate
            if ff:
                opts["ffmpeg_location"] = ff
            if audio and ff:
                opts["postprocessors"] = [{"key": "FFmpegExtractAudio", "preferredcodec": "mp3", "preferredquality": "192"}]
            self._base = self._cur = 0
            with yt_dlp.YoutubeDL(opts) as ydl:
                info = ydl.extract_info(self.url, download=True)
                if info.get("entries"):
                    info = next((e for e in info["entries"] if e), info)
                path = None
                rd = info.get("requested_downloads") or []
                if rd and rd[0].get("filepath"):
                    path = rd[0]["filepath"]
                if not path:
                    path = ydl.prepare_filename(info)
                    if audio and ff:
                        path = os.path.splitext(path)[0] + ".mp3"
            if path and os.path.exists(path):
                self.path = path
                self.name = os.path.basename(path)
                self.cat = category_of(self.name)
                self.size = os.path.getsize(path)
                self.status = "completed"
                self.completed_at = time.time()
                self.speed = 0.0
            else:
                self.error = "The video file was not created"
                self.status = "error"
        except DownloadCancelled:
            self.status = "paused"
        except Exception as e:  # noqa
            msg = str(e)
            for junk in ("ERROR: ", "\x1b[0;31mERROR:\x1b[0m "):
                msg = msg.replace(junk, "")
            self.error = msg[:300] or "Video download failed"
            self.status = "error"
