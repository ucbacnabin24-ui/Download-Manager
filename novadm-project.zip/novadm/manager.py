"""Queue, scheduler, persistence, events, clipboard watcher."""
import json
import os
import re
import threading
import time
import urllib.parse

from . import winutils
from .config import ALL_CATEGORIES, Settings, data_dir
from .engine import LIMITER, Download, expand_pattern
from .video import VideoDownload

DOWNLOAD_EXT = re.compile(
    r"\.(zip|rar|7z|tar|gz|bz2|xz|iso|cab|zst|pdf|docx?|xlsx?|pptx?|epub|csv|rtf|odt|mobi|mp3|wav|flac|aac|ogg|m4a|wma|opus|"
    r"exe|msi|apk|dmg|deb|rpm|appimage|msix|jar|mp4|mkv|avi|mov|wmv|flv|webm|m4v|ts|mpe?g|3gp|jpe?g|png|gif|webp|bmp|tiff?|heic)$",
    re.I)
VIDEO_PATTERNS = {
    "youtube.com": r"^/(watch|shorts/|live/)", "youtu.be": r"^/.+",
    "facebook.com": r"(^/watch|/videos/|/reel/|/share/v/)", "fb.watch": r"^/.+",
    "vimeo.com": r"^/\d+", "twitter.com": r"/status/\d+", "x.com": r"/status/\d+",
    "instagram.com": r"^/(p|reel|reels|tv)/", "dailymotion.com": r"^/video/",
    "tiktok.com": r"/video/\d+", "twitch.tv": r"(/videos/|/clip/)", "reddit.com": r"/comments/",
}


def valid_url(u: str) -> bool:
    try:
        p = urllib.parse.urlparse(u)
        return p.scheme in ("http", "https") and bool(p.netloc) and len(u) < 4000
    except Exception:
        return False


def is_video_url(u: str) -> bool:
    try:
        p = urllib.parse.urlparse(u)
        h = (p.hostname or "").lower()
    except Exception:
        return False
    for host, pat in VIDEO_PATTERNS.items():
        if h == host or h.endswith("." + host):
            return bool(re.search(pat, p.path))
    return False


def looks_like_download(u: str) -> bool:
    if not valid_url(u) or "\n" in u or " " in u:
        return False
    return bool(DOWNLOAD_EXT.search(urllib.parse.urlparse(u).path)) or is_video_url(u)


def parse_hhmm(s):
    m = re.fullmatch(r"\s*(\d{1,2}):(\d{2})\s*", s or "")
    if not m:
        return None
    h, mi = int(m.group(1)), int(m.group(2))
    return (h, mi) if h < 24 and mi < 60 else None


class Manager:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.lock = threading.RLock()
        self.downloads = {}
        self.events = []
        self.seq = 0
        self.path = os.path.join(data_dir(), "downloads.json")
        self._dirty = False
        self._last_save = 0.0
        self._prev = {}
        self.stop_evt = threading.Event()
        self.batch_active = False
        self.batch_done = 0
        self.ffmpeg = {"busy": False, "pct": 0, "error": ""}
        self.notify = None          # callable(title, message)
        self.quit_cb = None         # callable()
        self.last_clip = ""
        self.ext_seen = 0.0         # last time the browser extension talked to us
        self._threads = []
        self.load()
        self.apply_limits()

    # ------------------------------------------------------------------ persistence
    def load(self):
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                items = json.load(f)
        except Exception:
            items = []
        for d in items:
            try:
                cls = VideoDownload if d.get("kind") == "video" else Download
                o = cls.from_dict(d)
                self.downloads[o.id] = o
                self._prev[o.id] = o.status
            except Exception:
                continue

    def save(self, force=False):
        now = time.time()
        if not force and now - self._last_save < 2.5:
            return
        self._last_save = now
        with self.lock:
            data = [d.to_dict() for d in self.downloads.values()]
        tmp = self.path + ".tmp"
        try:
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(data, f)
            os.replace(tmp, self.path)
            self._dirty = False
        except OSError:
            pass

    def apply_limits(self):
        s = self.settings
        LIMITER.set_rate(s.get("limit_kbps") * 1024 if s.get("limit_on") else 0)

    # ------------------------------------------------------------------ events
    def event(self, kind, **kw):
        with self.lock:
            self.seq += 1
            self.events.append(dict(kw, seq=self.seq, kind=kind))
            self.events = self.events[-60:]

    def events_since(self, seq):
        with self.lock:
            return [e for e in self.events if e["seq"] > seq]

    # ------------------------------------------------------------------ adding
    def add_urls(self, urls, folder="", filename="", conns=None, start="now", at=0.0, user="", password="",
                 referer="", cookie="", ua="", desc="", pattern=False):
        ids = []
        flat = []
        for u in urls:
            for line in str(u).replace("\r", "\n").split("\n"):
                line = line.strip()
                if not line:
                    continue
                flat.extend(expand_pattern(line) if pattern else [line])
        if not flat:
            raise ValueError("Please enter a link")
        bad = [u for u in flat if not valid_url(u)]
        if bad and len(bad) == len(flat):
            raise ValueError("That is not a valid http/https link")
        base = (folder or "").strip()
        auto = False
        if not base:
            base = self.settings.base_folder()
            auto = bool(self.settings.get("sort_folders"))
        c = int(conns or self.settings.get("conns"))
        for u in flat:
            if not valid_url(u):
                continue
            d = Download(u, base, filename=filename if len(flat) == 1 else "", conns=max(1, min(32, c)),
                         auto_sort=auto, user=user, password=password, referer=referer, cookie=cookie, ua=ua, desc=desc)
            self._set_start(d, start, at)
            with self.lock:
                self.downloads[d.id] = d
                self._prev[d.id] = d.status
            ids.append(d.id)
        self._dirty = True
        self.save(True)
        return ids

    def add_video(self, url, fmt="best", folder="", referer="", cookie=""):
        if not valid_url(url):
            raise ValueError("That is not a valid http/https link")
        base = (folder or "").strip()
        auto = False
        if not base:
            base = self.settings.base_folder()
            auto = bool(self.settings.get("sort_folders"))
        d = VideoDownload(url, base, vfmt=fmt or "best", auto_sort=auto, referer=referer, cookie=cookie)
        with self.lock:
            self.downloads[d.id] = d
            self._prev[d.id] = d.status
        self._dirty = True
        self.save(True)
        return [d.id]

    def _set_start(self, d, start, at):
        if start == "later":
            d.status = "paused"
        elif start == "at" and at and at > time.time():
            d.status = "scheduled"
            d.start_at = float(at)
        else:
            d.status = "queued"

    # ------------------------------------------------------------------ actions
    def get(self, i):
        with self.lock:
            return self.downloads.get(i)

    def pause(self, ids):
        for i in ids:
            d = self.get(i)
            if d and d.status in ("downloading", "queued", "scheduled"):
                d.pause()
                if not d.active:
                    d.status = "paused"
        self._dirty = True

    def resume(self, ids):
        for i in ids:
            d = self.get(i)
            if d and d.status in ("paused", "error", "scheduled"):
                d.error = ""
                d.stop_evt.clear()
                d.status = "queued"
        self._dirty = True

    def pause_all(self):
        with self.lock:
            ids = list(self.downloads)
        self.pause(ids)

    def resume_all(self):
        with self.lock:
            ids = [i for i, d in self.downloads.items() if d.status in ("paused", "error", "scheduled")]
        self.resume(ids)

    def remove(self, ids, delete_files=False):
        for i in ids:
            d = self.get(i)
            if not d:
                continue
            d.removed = True
            d.pause()
            t = d.thread
            if t is not None and t.is_alive():
                t.join(timeout=3)
            if delete_files or d.status != "completed":
                d.delete_files()
            with self.lock:
                self.downloads.pop(i, None)
                self._prev.pop(i, None)
        self.save(True)

    def redownload(self, ids):
        for i in ids:
            d = self.get(i)
            if not d:
                continue
            d.removed = True
            d.pause()
            t = d.thread
            if t is not None and t.is_alive():
                t.join(timeout=3)
            d.removed = False
            d.delete_files()
            d.segs = []
            d.path = ""
            d.size = -1
            d.error = ""
            d.warn = ""
            d.speed = 0.0
            d._last_t = 0.0
            d.stop_evt.clear()
            if isinstance(d, VideoDownload):
                d._base = d._cur = 0
            d.status = "queued"
        self._dirty = True

    def clear_completed(self):
        with self.lock:
            ids = [i for i, d in self.downloads.items() if d.status == "completed"]
        for i in ids:
            self.remove([i], False)

    # ------------------------------------------------------------------ scheduler
    def _window_open(self, now_struct):
        s = self.settings
        if not s.get("sched_on"):
            return True
        st = parse_hhmm(s.get("sched_start"))
        sp = parse_hhmm(s.get("sched_stop"))
        cur = now_struct.tm_hour * 60 + now_struct.tm_min
        a = st[0] * 60 + st[1] if st else 0
        b = sp[0] * 60 + sp[1] if sp else 24 * 60
        if a == b:
            return True
        return (a <= cur < b) if a < b else (cur >= a or cur < b)

    def tick(self):
        now = time.time()
        with self.lock:
            items = list(self.downloads.values())
        for d in items:
            if d.status == "scheduled" and d.start_at and now >= d.start_at:
                d.status = "queued"
        open_ = self._window_open(time.localtime(now))
        n_active = sum(1 for d in items if d.status == "downloading")
        max_active = self.settings.get("max_active")
        if open_:
            for d in items:
                if n_active >= max_active:
                    break
                if d.status == "queued" and not d.removed:
                    d.start()
                    n_active += 1
                    self.batch_active = True
        elif self.settings.get("sched_stop"):
            for d in items:
                if d.status == "downloading":
                    d.pause()
                    d.status = "queued"       # resumes automatically at the next window
        for d in items:
            d.sample(now)
            old = self._prev.get(d.id)
            if old != d.status:
                self._prev[d.id] = d.status
                self._dirty = True
                if d.status == "completed" and old in ("downloading", "queued", "paused"):
                    self.batch_done += 1
                    self.event("complete", id=d.id, name=d.name, path=d.path)
                    if self.notify:
                        self.notify("Download complete", d.name)
                elif d.status == "error":
                    self.event("error", id=d.id, name=d.name, error=d.error)
        if any(d.status == "downloading" for d in items):
            self._dirty = True
        if self._dirty:
            self.save()
        # finished everything?
        if self.batch_active and not any(d.status in ("downloading", "queued", "scheduled") for d in items):
            self.batch_active = False
            done, self.batch_done = self.batch_done, 0
            action = self.settings.get("after_all")
            if done and action != "nothing":
                self.event("after_all", action=action)
                if action == "close" and self.quit_cb:
                    self.quit_cb()
                elif action in ("sleep", "shutdown"):
                    self.save(True)
                    winutils.system_action(action)

    # ------------------------------------------------------------------ extension / clipboard
    def add_from_extension(self, p: dict):
        self.ext_seen = time.time()
        url = str(p.get("url", ""))
        if not valid_url(url):
            raise ValueError("bad url")
        if p.get("video"):
            ids = self.add_video(url, str(p.get("quality") or "best"), referer=str(p.get("referer", "")),
                                 cookie=str(p.get("cookie", ""))[:8000])
        else:
            ids = self.add_urls([url], filename=str(p.get("filename", ""))[:200], referer=str(p.get("referer", ""))[:2000],
                                cookie=str(p.get("cookie", ""))[:8000], ua=str(p.get("ua", ""))[:500])
        d = self.get(ids[0])
        self.event("added", id=ids[0], name=(d.name or url) if d else url)
        return ids

    def _clip_loop(self):
        try:
            self.last_clip = (winutils.clipboard_text() or "").strip()     # ignore what was copied before launch
        except Exception:
            pass
        while not self.stop_evt.wait(1.2):
            if not self.settings.get("clip_monitor"):
                continue
            t = (winutils.clipboard_text() or "").strip()
            if t and t != self.last_clip:
                self.last_clip = t
                if looks_like_download(t):
                    self.event("clip", url=t, video=is_video_url(t))

    # ------------------------------------------------------------------ ffmpeg
    def install_ffmpeg(self):
        if self.ffmpeg["busy"]:
            return
        self.ffmpeg.update(busy=True, pct=0, error="")

        def work():
            from .video import install_ffmpeg
            try:
                install_ffmpeg(lambda p: self.ffmpeg.update(pct=p))
            except Exception as e:  # noqa
                self.ffmpeg["error"] = str(e)[:200] or "Download failed"
            self.ffmpeg["busy"] = False

        threading.Thread(target=work, daemon=True).start()

    # ------------------------------------------------------------------ lifecycle
    def start(self):
        def loop():
            while not self.stop_evt.wait(0.5):
                try:
                    self.tick()
                except Exception:
                    pass
        t = threading.Thread(target=loop, daemon=True, name="manager")
        t.start()
        c = threading.Thread(target=self._clip_loop, daemon=True, name="clipboard")
        c.start()
        self._threads = [t, c]

    def shutdown(self):
        self.stop_evt.set()
        with self.lock:
            items = list(self.downloads.values())
        for d in items:
            if d.status == "downloading":
                d.pause()
        for d in items:
            t = d.thread
            if t is not None and t.is_alive():
                t.join(timeout=3)
        self.save(True)

    # ------------------------------------------------------------------ snapshots for the UI
    def snapshot(self):
        with self.lock:
            items = list(self.downloads.values())
        out = []
        counts = {"all": 0, "downloading": 0, "queued": 0, "completed": 0, "unfinished": 0, "error": 0}
        cats = {c: 0 for c in ALL_CATEGORIES}
        total_speed = 0.0
        for d in items:
            counts["all"] += 1
            if d.status in ("downloading",):
                counts["downloading"] += 1
            if d.status in ("queued", "scheduled"):
                counts["queued"] += 1
            if d.status == "completed":
                counts["completed"] += 1
            else:
                counts["unfinished"] += 1
            if d.status == "error":
                counts["error"] += 1
            cats[d.cat if d.cat in cats else "Other"] += 1
            total_speed += d.speed
            out.append({
                "id": d.id, "name": d.name or d.url.split("/")[-1][:60] or d.url, "url": d.url, "size": d.size,
                "done": d.downloaded, "speed": int(d.speed), "eta": int(d.eta), "status": d.status,
                "error": d.error, "warn": d.warn, "cat": d.cat if d.cat in cats else "Other", "added": d.added,
                "completed_at": d.completed_at, "path": d.path, "folder": d.folder, "conns": len(d.segs) if d.status == "downloading" else d.conns,
                "resumable": d.resumable, "kind": d.kind, "start_at": d.start_at, "desc": d.desc,
                "last_try": d.last_try, "segs_n": len(d.segs),
            })
        out.sort(key=lambda x: x["added"], reverse=True)
        return {"downloads": out, "counts": counts, "cats": cats, "speed": int(total_speed), "seq": self.seq,
                "ext_connected": (time.time() - self.ext_seen) < 120 if self.ext_seen else False}

    def segments(self, i):
        d = self.get(i)
        if not d:
            return {"size": 0, "segs": []}
        return {"size": d.size, "segs": [[s.start, min(s.end, d.size - 1) if d.size > 0 else s.end, s.pos] for s in list(d.segs)]
                if d.size > 0 else []}
