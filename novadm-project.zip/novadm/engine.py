"""Download engine: multi-connection segmented downloads with dynamic splitting,
resume, retry, throttling-awareness, speed limiter.  Pure standard library."""
import base64
import http.client
import mimetypes
import os
import re
import socket
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid

from .config import category_of

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36")
CHUNK = 64 * 1024
MIN_SEG = 512 * 1024          # do not make segments smaller than this at start
MIN_SPLIT = 1024 * 1024       # a running segment is split only if >= 2 * MIN_SPLIT remains
REWIND = 256 * 1024           # safety margin when resuming from saved state
MAX_FAILS = 10
INF = 1 << 62

_NAME_LOCK = threading.Lock()


class Limiter:
    """Global speed limiter shared by all downloads (bytes per second, 0 = unlimited)."""

    def __init__(self):
        self.rate = 0
        self._next = 0.0
        self._lock = threading.Lock()

    def set_rate(self, bytes_per_sec: int):
        with self._lock:
            self.rate = max(0, int(bytes_per_sec))
            self._next = 0.0

    def consume(self, n: int):
        r = self.rate
        if r <= 0:
            return
        with self._lock:
            now = time.monotonic()
            t = max(self._next, now) + n / r
            self._next = t
            wait = t - now - 0.25          # allow a small burst
        if wait > 0:
            time.sleep(min(wait, 5))


LIMITER = Limiter()


# ----------------------------------------------------------------------------- helpers
_BAD = re.compile(r'[\\/:*?"<>|\x00-\x1f]')
_RESERVED = {"con", "prn", "aux", "nul"} | {f"com{i}" for i in range(1, 10)} | {f"lpt{i}" for i in range(1, 10)}


def sanitize(name: str) -> str:
    name = _BAD.sub("_", name or "").strip().strip(".")
    if not name:
        name = "download"
    if name.split(".")[0].lower() in _RESERVED:
        name = "_" + name
    return name[:180]


def parse_content_disposition(value):
    if not value:
        return None
    m = re.search(r"filename\*\s*=\s*([^']*)'[^']*'([^;]+)", value, re.I)
    if m:
        enc = (m.group(1) or "utf-8").strip() or "utf-8"
        try:
            return urllib.parse.unquote(m.group(2).strip().strip('"'), encoding=enc)
        except Exception:
            pass
    m = re.search(r'filename\s*=\s*"([^"]+)"', value, re.I) or re.search(r"filename\s*=\s*([^;]+)", value, re.I)
    if m:
        name = m.group(1).strip().strip('"')
        try:   # headers are decoded as latin-1; most servers actually send UTF-8
            name = name.encode("latin-1").decode("utf-8")
        except Exception:
            pass
        return name
    return None


def name_from_url(url: str) -> str:
    p = urllib.parse.urlparse(url)
    n = urllib.parse.unquote(os.path.basename(p.path.rstrip("/")))
    if not n:
        qs = urllib.parse.parse_qs(p.query)
        for k in ("filename", "file", "name", "title"):
            if k in qs and qs[k]:
                n = qs[k][0]
                break
    return n or (p.hostname or "download")


def ext_from_ctype(ct: str) -> str:
    ct = (ct or "").split(";")[0].strip().lower()
    if not ct or ct in ("application/octet-stream", "binary/octet-stream"):
        return ""
    ext = mimetypes.guess_extension(ct) or ""
    return {".jpe": ".jpg", ".jpeg": ".jpg"}.get(ext, ext)


def unique_path(folder: str, name: str) -> str:
    base, ext = os.path.splitext(name)
    cand = name
    i = 1
    while os.path.exists(os.path.join(folder, cand)) or os.path.exists(os.path.join(folder, cand) + ".part"):
        cand = f"{base} ({i}){ext}"
        i += 1
    return os.path.join(folder, cand)


def expand_pattern(url: str, limit: int = 5000):
    """http://x/img[01-10].jpg  or  http://x/[a-e].zip  -> list of URLs."""
    m = re.search(r"\[(\w+)-(\w+)\]", url)
    if not m:
        return [url]
    a, b = m.group(1), m.group(2)
    vals = None
    if a.isdigit() and b.isdigit():
        width = len(a) if a.startswith("0") and len(a) > 1 else 0
        lo, hi = int(a), int(b)
        step = 1 if hi >= lo else -1
        vals = [str(i).zfill(width) for i in range(lo, hi + step, step)]
    elif len(a) == 1 and len(b) == 1 and a.isalpha() and b.isalpha():
        lo, hi = ord(a), ord(b)
        step = 1 if hi >= lo else -1
        vals = [chr(i) for i in range(lo, hi + step, step)]
    if vals is None:
        return [url]
    out = []
    for v in vals:
        for u in expand_pattern(url[:m.start()] + v + url[m.end():], limit):
            out.append(u)
            if len(out) >= limit:
                return out
    return out


class HttpStatus(Exception):
    def __init__(self, code, reason=""):
        super().__init__(f"HTTP {code} {reason}".strip())
        self.code = code


class RangeIgnored(Exception):
    pass


class Segment:
    __slots__ = ("start", "end", "pos", "owner")

    def __init__(self, start, end, pos=None):
        self.start = start
        self.end = end          # inclusive
        self.pos = start if pos is None else pos
        self.owner = None

    def done(self):
        return self.pos > self.end


# ----------------------------------------------------------------------------- download
PERSIST = ("id", "url", "final_url", "filename", "name", "folder", "path", "size", "resumable", "status",
           "error", "cat", "added", "last_try", "completed_at", "conns", "referer", "cookie", "ua",
           "user", "password", "desc", "start_at", "kind", "vfmt", "warn", "auto_sort")


class Download:
    kind = "http"

    def __init__(self, url, folder, **opt):
        self.id = opt.get("id") or uuid.uuid4().hex[:12]
        self.url = url
        self.final_url = opt.get("final_url") or url
        self.filename = opt.get("filename") or ""
        self.name = opt.get("name") or ""
        self.folder = folder
        self.path = opt.get("path") or ""
        self.size = opt.get("size", -1)
        self.resumable = opt.get("resumable", False)
        self.status = opt.get("status", "queued")   # queued scheduled downloading paused completed error
        self.error = opt.get("error", "")
        self.warn = opt.get("warn", "")
        self.cat = opt.get("cat", "Other")
        self.added = opt.get("added") or time.time()
        self.last_try = opt.get("last_try", 0)
        self.completed_at = opt.get("completed_at", 0)
        self.conns = int(opt.get("conns", 8))
        self.referer = opt.get("referer", "")
        self.cookie = opt.get("cookie", "")
        self.ua = opt.get("ua", "")
        self.user = opt.get("user", "")
        self.password = opt.get("password", "")
        self.desc = opt.get("desc", "")
        self.start_at = opt.get("start_at", 0.0)
        self.vfmt = opt.get("vfmt", "")
        self.auto_sort = bool(opt.get("auto_sort", False))
        self.segs = []
        self.lock = threading.Lock()
        self.stop_evt = threading.Event()      # set by the user (pause / delete)
        self.abort_evt = threading.Event()     # set internally (error / fallback)
        self.thread = None
        self.allowed = 1
        self._fallback = False
        self.speed = 0.0
        self._last_t = 0.0
        self._last_b = 0
        self.removed = False

    # ---- persistence
    def to_dict(self):
        d = {k: getattr(self, k) for k in PERSIST}
        d["kind"] = self.kind
        if d["status"] == "downloading":
            d["status"] = "paused"
        d["segs"] = [[s.start, s.end, s.pos] for s in list(self.segs)]
        return d

    @classmethod
    def from_dict(cls, d):
        o = cls(d["url"], d.get("folder", ""), **{k: d[k] for k in PERSIST if k in d and k not in ("url", "folder")})
        for st, en, pos in d.get("segs", []):
            s = Segment(st, en, max(st, pos - REWIND) if o.status != "completed" else pos)
            o.segs.append(s)
        if o.status == "downloading":
            o.status = "paused"
        return o

    # ---- state
    @property
    def part_path(self):
        return self.path + ".part"

    @property
    def downloaded(self):
        if self.status == "completed":
            return max(self.size, 0)
        return sum(max(0, min(s.pos, s.end + 1) - s.start) for s in list(self.segs))

    def sample(self, now):
        b = self.downloaded
        if self._last_t == 0.0:
            self._last_t, self._last_b = now, b
            return
        dt = now - self._last_t
        if dt >= 0.5:
            inst = max(0.0, (b - self._last_b) / dt)
            self.speed = inst if self.speed == 0 else 0.6 * self.speed + 0.4 * inst
            self._last_t, self._last_b = now, b
        if self.status != "downloading":
            self.speed = 0.0

    @property
    def eta(self):
        if self.speed > 1 and self.size > 0:
            return (self.size - self.downloaded) / self.speed
        return -1

    @property
    def active(self):
        return self.thread is not None and self.thread.is_alive()

    # ---- control
    def start(self):
        if self.active:
            return
        self.stop_evt.clear()
        self.abort_evt.clear()
        self.status = "downloading"
        self.error = ""
        self.thread = threading.Thread(target=self._run, daemon=True, name="dl-" + self.id)
        self.thread.start()

    def pause(self):
        self.stop_evt.set()
        if not self.active and self.status in ("queued", "downloading", "scheduled"):
            self.status = "paused"

    def delete_files(self):
        for p in (self.path, self.part_path):
            if p:
                try:
                    os.remove(p)
                except OSError:
                    pass

    # ---- http
    def _headers(self, extra=None):
        h = {"User-Agent": self.ua or UA, "Accept": "*/*", "Accept-Encoding": "identity",
             "Connection": "close"}
        if self.referer:
            h["Referer"] = self.referer
        if self.cookie:
            h["Cookie"] = self.cookie
        if self.user:
            tok = base64.b64encode(f"{self.user}:{self.password}".encode("utf-8")).decode("ascii")
            h["Authorization"] = "Basic " + tok
        if extra:
            h.update(extra)
        return h

    def _open(self, url, extra=None, timeout=30):
        req = urllib.request.Request(url, headers=self._headers(extra))
        return urllib.request.urlopen(req, timeout=timeout)

    def _probe(self):
        resp = None
        for use_range in (True, False):
            try:
                resp = self._open(self.url, {"Range": "bytes=0-0"} if use_range else None)
                break
            except urllib.error.HTTPError as e:
                code, reason = e.code, e.reason
                e.close()
                if use_range and code == 416:        # empty file
                    self.size, self.resumable, self.final_url = 0, False, self.url
                    self._finish_probe(None)
                    return
                if use_range and code in (400, 405, 500, 501, 502, 503):
                    continue
                raise HttpStatus(code, reason)
        status = resp.status
        self.final_url = resp.geturl()
        h = resp.headers
        size, resumable = -1, False
        cr = h.get("Content-Range")
        if status == 206 and cr:
            m = re.match(r"\s*bytes\s+\d+-\d+/(\d+|\*)", cr)
            if m and m.group(1).isdigit():
                size = int(m.group(1))
            resumable = size > 0
        else:
            cl = h.get("Content-Length")
            if cl and cl.isdigit():
                size = int(cl)
            resumable = "bytes" in (h.get("Accept-Ranges") or "").lower() and size > 0
        self.size, self.resumable = size, resumable
        self._finish_probe(h)
        try:
            resp.close()
        except Exception:
            pass

    def _finish_probe(self, h):
        name = self.filename
        ctype = ""
        if h is not None:
            ctype = h.get("Content-Type", "") or ""
            if not name:
                name = parse_content_disposition(h.get("Content-Disposition"))
        if not name:
            name = name_from_url(self.final_url) or name_from_url(self.url)
        name = sanitize(name)
        if "." not in name:
            name += ext_from_ctype(ctype)
        if ctype.lower().startswith("text/html") and not name.lower().endswith((".html", ".htm", ".php", ".asp", ".aspx")) \
                and 0 <= self.size < 300_000:
            self.warn = "The server returned a web page, not a file (the link may have expired or needs login)."
        self.name = name
        self.cat = category_of(name)

    def _plan(self):
        if self.auto_sort:
            self.folder = os.path.join(self.folder, self.cat)
            self.auto_sort = False
        os.makedirs(self.folder, exist_ok=True)
        with _NAME_LOCK:
            self.path = unique_path(self.folder, self.name)
            self.name = os.path.basename(self.path)
            with open(self.part_path, "wb") as f:
                if self.size > 0:
                    f.truncate(self.size)
        self.segs = []
        if self.size > 0 and self.resumable and self.conns > 1 and self.size >= 4 * MIN_SEG:
            n = max(1, min(self.conns, self.size // MIN_SEG))
            step = self.size // n
            for i in range(n):
                st = i * step
                en = self.size - 1 if i == n - 1 else (i + 1) * step - 1
                self.segs.append(Segment(st, en))
        elif self.size >= 0:
            self.segs.append(Segment(0, self.size - 1))
        else:
            self.segs.append(Segment(0, INF))

    # ---- main thread of one download
    def _run(self):
        try:
            self.last_try = time.time()
            if not self.segs:
                self._probe()
                self._plan()
            elif not os.path.exists(self.part_path):
                if self.size < 0 and not self.path:
                    self.segs = []
                    self._probe()
                self._plan()
            if self.size == 0:
                open(self.part_path, "wb").close()
                self.segs = [Segment(0, -1)]
            self._transfer()
            if self.removed:
                return
            if self.error:
                self.status = "error"
            elif self.stop_evt.is_set():
                self.status = "paused"
            else:
                self._finalize()
        except HttpStatus as e:
            self.error = {401: "Login required (HTTP 401)", 403: "Access denied (HTTP 403)", 404: "File not found (HTTP 404)",
                          410: "The link is no longer available (HTTP 410)"}.get(e.code, str(e))
            self.status = "error"
        except Exception as e:  # noqa
            self.error = self.error or (str(e) or e.__class__.__name__)
            self.status = "error"

    def _finalize(self):
        left = [s for s in self.segs if not s.done()]
        if left or (self.size >= 0 and self.downloaded < self.size):
            self.error = "Download incomplete"
            self.status = "error"
            return
        if self.size < 0:
            self.size = self.downloaded
        os.replace(self.part_path, self.path)
        self.completed_at = time.time()
        self.speed = 0.0
        self.status = "completed"

    def _halted(self):
        return self.stop_evt.is_set() or self.abort_evt.is_set()

    def _abort(self, msg=None):
        if msg and not self.error:
            self.error = msg
        self.abort_evt.set()

    def _transfer(self):
        while True:
            self.abort_evt.clear()
            self._fallback = False
            pending = [s for s in self.segs if not s.done()]
            if not pending:
                return
            n = max(1, min(self.conns, len(pending))) if self.resumable else 1
            self.allowed = n
            for s in self.segs:
                s.owner = None
            threads = [threading.Thread(target=self._worker, args=(i,), daemon=True) for i in range(n)]
            for t in threads:
                t.start()
            for t in threads:
                t.join()
            if self._fallback and not self.stop_evt.is_set():
                self._make_single()
                continue
            return

    def _make_single(self):
        self.resumable = False
        self.segs = [Segment(0, self.size - 1 if self.size >= 0 else INF)]
        try:
            with open(self.part_path, "r+b") as f:
                f.truncate(max(0, self.size) if self.size > 0 else 0)
        except OSError:
            pass

    def _throttle(self):
        with self.lock:
            self.allowed = max(1, self.allowed // 2)

    def _claim(self, wid):
        with self.lock:
            for s in self.segs:
                if s.owner is None and not s.done():
                    s.owner = wid
                    return s
            if not self.resumable or self.size < 0:
                return None
            best, rem = None, 0
            for s in self.segs:
                if s.owner is not None and not s.done():
                    r = s.end - s.pos + 1
                    if r > rem:
                        best, rem = s, r
            if best is not None and rem >= 2 * MIN_SPLIT:
                mid = best.pos + rem // 2
                new = Segment(mid, best.end)
                best.end = mid - 1
                new.owner = wid
                self.segs.insert(self.segs.index(best) + 1, new)
                return new
        return None

    def _worker(self, wid):
        while not self._halted() and wid < self.allowed:
            seg = self._claim(wid)
            if seg is None:
                return
            try:
                ok = self._fetch(seg, wid)
            except RangeIgnored:
                self._fallback = True
                self.abort_evt.set()
                ok = False
            finally:
                with self.lock:
                    seg.owner = None
            if ok:
                continue
            if self._halted() or wid >= self.allowed:
                return
            self._abort("Download failed")
            return

    def _fetch(self, seg, wid):
        fails = 0
        f = None
        try:
            f = open(self.part_path, "r+b")
            while not self._halted() and wid < self.allowed:
                if self.size >= 0 and seg.pos > seg.end:
                    return True
                before = seg.pos
                try:
                    if self.resumable:
                        rng = {"Range": "bytes=%d-%s" % (seg.pos, seg.end if seg.end < INF else "")}
                    else:
                        rng = None
                        if seg.pos != seg.start:           # cannot resume: restart this body
                            seg.pos = seg.start
                            before = seg.pos
                    resp = self._open(self.final_url, rng)
                    try:
                        if rng and resp.status == 200:
                            if not (seg.start == 0 and seg.pos == 0 and len(self.segs) == 1):
                                raise RangeIgnored()
                        elif rng and resp.status != 206:
                            raise HttpStatus(resp.status)
                        while not self._halted():
                            want = CHUNK
                            if self.size >= 0:
                                rem = seg.end - seg.pos + 1
                                if rem <= 0:
                                    break
                                want = min(CHUNK, rem)
                            chunk = resp.read(want)
                            if not chunk:
                                break
                            LIMITER.consume(len(chunk))
                            with self.lock:
                                n = len(chunk) if self.size < 0 else min(len(chunk), seg.end - seg.pos + 1)
                                if n <= 0:
                                    break
                                p = seg.pos
                                seg.pos += n
                            f.seek(p)
                            f.write(chunk if n == len(chunk) else chunk[:n])
                            fails = 0
                            if n < len(chunk):
                                break
                    finally:
                        try:
                            resp.close()
                        except Exception:
                            pass
                    if self._halted():
                        return False
                    if self.size < 0:                       # unknown size: EOF = finished
                        with self.lock:
                            seg.end = seg.pos - 1
                        return True
                    if seg.pos > seg.end:
                        return True
                    fails = fails + 1 if seg.pos == before else 0
                    if fails > MAX_FAILS:
                        self._abort("The connection keeps closing early")
                        return False
                    time.sleep(min(0.4 * fails, 4))
                except RangeIgnored:
                    raise
                except (urllib.error.HTTPError, HttpStatus) as e:
                    code = e.code
                    try:
                        e.close()
                    except Exception:
                        pass
                    if code == 416:
                        if self.size >= 0 and seg.pos >= self.size:
                            return True
                        self._abort("Server rejected the byte range (HTTP 416)")
                        return False
                    if code in (401, 407):
                        self._abort("Login required (HTTP %d)" % code)
                        return False
                    if code in (404, 410, 451):
                        self._abort("File not found / link expired (HTTP %d)" % code)
                        return False
                    if code in (403, 429, 503):             # often a per-IP connection limit
                        fails += 1
                        if self.allowed > 1:
                            self._throttle()
                        if code == 403 and self.allowed <= 1 and fails > 3:
                            self._abort("Access denied (HTTP 403)")
                            return False
                    else:
                        fails += 1
                    if fails > MAX_FAILS:
                        self._abort("Server error (HTTP %d)" % code)
                        return False
                    if wid >= self.allowed:
                        return False
                    time.sleep(min(2 ** min(fails, 4), 15))
                except (OSError, http.client.HTTPException, socket.timeout) as e:
                    fails += 1
                    if fails > MAX_FAILS:
                        self._abort("Connection lost: " + (str(e) or e.__class__.__name__))
                        return False
                    time.sleep(min(2 ** min(fails, 4), 15))
            return False
        except OSError as e:                               # disk errors (file locked, disk full ...)
            self._abort("Cannot write the file: " + str(e))
            return False
        finally:
            if f is not None:
                try:
                    f.close()
                except OSError:
                    pass
