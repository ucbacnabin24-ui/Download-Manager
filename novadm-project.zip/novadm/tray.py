"""System-tray icon (optional: needs pystray + Pillow, silently skipped otherwise)."""


def start_tray(show, pause_all, resume_all, quit_app):
    try:
        import pystray
        from .icon import draw_icon
    except Exception:
        return None
    try:
        menu = pystray.Menu(
            pystray.MenuItem("Open NovaDM", lambda icon, item: show(), default=True),
            pystray.MenuItem("Pause all", lambda icon, item: pause_all()),
            pystray.MenuItem("Resume all", lambda icon, item: resume_all()),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem("Quit", lambda icon, item: quit_app()),
        )
        icon = pystray.Icon("NovaDM", draw_icon(64), "NovaDM", menu)
        icon.run_detached()
        return icon
    except Exception:
        return None
