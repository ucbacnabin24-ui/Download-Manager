(() => {
"use strict";
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
const TOKEN = window.NOVADM.token;

async function api(path, body) {
  const opt = body === undefined ? {headers: {"X-Token": TOKEN}}
    : {method: "POST", headers: {"X-Token": TOKEN, "Content-Type": "application/json"}, body: JSON.stringify(body)};
  const r = await fetch("/api/" + path, opt);
  let j = {};
  try { j = await r.json(); } catch (e) {}
  if (!r.ok) throw new Error(j.error || ("Error " + r.status));
  return j;
}

/* ------------------------------------------------------------------ state */
let S = {downloads: [], counts: {}, cats: {}, settings: {}, video: {}, seq: 0, speed: 0};
let filt = {type: "status", key: "all"};
let sel = new Set(), lastClicked = null, detailId = null;
let sortKey = "added", sortDir = -1, lastIds = "";
const CAT_COLOR = {Compressed: "#a855f7", Documents: "#3b82f6", Music: "#ec4899", Programs: "#f97316", Video: "#ef4444", Images: "#14b8a6", Other: "#64748b"};
const STATUS_NAV = [["all", "All downloads"], ["downloading", "Downloading"], ["queued", "Queued"], ["unfinished", "Unfinished"], ["completed", "Completed"], ["error", "Failed"]];
const ST_TXT = {downloading: "Downloading", queued: "Queued", scheduled: "Scheduled", paused: "Paused", completed: "Complete", error: "Failed"};

/* ------------------------------------------------------------------ formatting */
function fmtBytes(n) {
  if (n == null || n < 0) return "—";
  const u = ["B", "KB", "MB", "GB", "TB"]; let i = 0, v = n;
  while (v >= 1024 && i < u.length - 1) { v /= 1024; i++; }
  return (i === 0 ? v.toFixed(0) : v.toFixed(v >= 100 ? 0 : 1)) + " " + u[i];
}
function fmtSpeed(n) { return n > 0 ? fmtBytes(n) + "/s" : ""; }
function fmtEta(s) {
  if (s == null || s < 0) return "";
  s = Math.round(s);
  const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), x = s % 60;
  if (h > 0) return h + "h " + String(m).padStart(2, "0") + "m";
  if (m > 0) return m + "m " + String(x).padStart(2, "0") + "s";
  return x + "s";
}
function fmtDate(ts) {
  if (!ts) return "";
  const d = new Date(ts * 1000);
  return d.toLocaleDateString(undefined, {day: "2-digit", month: "short"}) + " " + d.toLocaleTimeString(undefined, {hour: "2-digit", minute: "2-digit"});
}
function host(u) { try { return new URL(u).hostname; } catch (e) { return u; } }
function extOf(name) { const m = /\.([A-Za-z0-9]{1,5})$/.exec(name || ""); return m ? m[1].toUpperCase() : "FILE"; }

/* ------------------------------------------------------------------ toasts */
function toast(title, msg, kind, actions, ms) {
  const el = document.createElement("div");
  el.className = "toast " + (kind || "");
  const b = document.createElement("b"); b.textContent = title; el.appendChild(b);
  if (msg) { const s = document.createElement("span"); s.textContent = msg; el.appendChild(s); }
  if (actions && actions.length) {
    const row = document.createElement("div"); row.className = "ta";
    actions.forEach(a => {
      const bt = document.createElement("button"); bt.className = "btn" + (a.primary ? " primary" : ""); bt.textContent = a.label;
      bt.onclick = () => { el.remove(); a.fn(); }; row.appendChild(bt);
    });
    el.appendChild(row);
  }
  $("#toasts").appendChild(el);
  setTimeout(() => el.remove(), ms || 6500);
}

/* ------------------------------------------------------------------ list rendering */
const ROW_HTML = `<div class="fname"><span class="badge"></span><div class="t"><b></b><small></small></div></div>
<div class="cell" data-f="size"></div>
<div class="prog"><div class="bar"><i></i></div><span class="pct"></span></div>
<div class="cell" data-f="speed"></div><div class="cell" data-f="eta"></div>
<div><span class="st" data-f="status"></span></div><div class="cell" data-f="added"></div>`;

function visible() {
  let a = S.downloads.filter(d => {
    if (filt.type === "cat") return d.cat === filt.key;
    switch (filt.key) {
      case "all": return true;
      case "queued": return d.status === "queued" || d.status === "scheduled";
      case "unfinished": return d.status !== "completed";
      default: return d.status === filt.key;
    }
  });
  const k = sortKey, dir = sortDir;
  a.sort((x, y) => {
    let r;
    if (k === "name") r = x.name.localeCompare(y.name);
    else if (k === "size") r = x.size - y.size;
    else if (k === "status") r = x.status.localeCompare(y.status);
    else r = x.added - y.added;
    return r * dir;
  });
  return a;
}

function updateRow(el, d) {
  const pct = d.status === "completed" ? 100 : (d.size > 0 ? Math.min(100, Math.floor(d.done * 100 / d.size)) : 0);
  const badge = $(".badge", el); badge.textContent = d.kind === "video" ? "VID" : extOf(d.name); badge.style.background = CAT_COLOR[d.cat] || CAT_COLOR.Other;
  const b = $(".t b", el); if (b.textContent !== d.name) b.textContent = d.name;
  const sub = d.error || d.warn || (d.status === "downloading" && d.size > 0 ? fmtBytes(d.done) + " of " + fmtBytes(d.size) : host(d.url));
  const sm = $(".t small", el); if (sm.textContent !== sub) sm.textContent = sub;
  sm.style.color = d.error ? "var(--err)" : (d.warn ? "var(--warn)" : "");
  el.title = d.url;
  $('[data-f="size"]', el).textContent = d.size > 0 ? fmtBytes(d.size) : (d.done > 0 ? fmtBytes(d.done) + "+" : "—");
  const bar = $(".bar", el); bar.className = "bar " + d.status; $("i", bar).style.width = pct + "%";
  $(".pct", el).textContent = pct + "%";
  $('[data-f="speed"]', el).textContent = d.status === "downloading" ? fmtSpeed(d.speed) : "";
  $('[data-f="eta"]', el).textContent = d.status === "downloading" ? fmtEta(d.eta) : "";
  const st = $('[data-f="status"]', el);
  st.className = "st " + d.status;
  st.textContent = ST_TXT[d.status] + (d.status === "scheduled" && d.start_at ? " " + new Date(d.start_at * 1000).toLocaleTimeString([], {hour: "2-digit", minute: "2-digit"}) : "");
  $('[data-f="added"]', el).textContent = fmtDate(d.added);
  el.classList.toggle("sel", sel.has(d.id));
}

function renderList() {
  const list = visible();
  const ids = list.map(d => d.id).join(",");
  const rows = $("#rows");
  if (ids !== lastIds) {
    lastIds = ids;
    rows.textContent = "";
    const frag = document.createDocumentFragment();
    list.forEach(d => {
      const el = document.createElement("div");
      el.className = "row"; el.dataset.id = d.id; el.innerHTML = ROW_HTML;
      updateRow(el, d); frag.appendChild(el);
    });
    rows.appendChild(frag);
  } else {
    const byId = {}; S.downloads.forEach(d => byId[d.id] = d);
    $$(".row", rows).forEach(el => { const d = byId[el.dataset.id]; if (d) updateRow(el, d); });
  }
  $("#empty").style.display = list.length ? "none" : "";
}

function renderNav() {
  const ns = $("#nav-status"), nc = $("#nav-cats");
  const mk = (type, key, label, n, color) => {
    const on = filt.type === type && filt.key === key;
    return `<div class="nav-i ${on ? "on" : ""}" data-type="${type}" data-key="${key}">` +
      (color ? `<span class="dot" style="background:${color}"></span>` : `<svg class="ic"><use href="#i-all"/></svg>`) +
      `<span>${label}</span><span class="n">${n || 0}</span></div>`;
  };
  ns.innerHTML = STATUS_NAV.map(([k, l]) => mk("status", k, l, S.counts[k])).join("");
  nc.innerHTML = Object.keys(CAT_COLOR).map(c => mk("cat", c, c, S.cats[c], CAT_COLOR[c])).join("");
  $("#ext-badge").innerHTML = S.ext_connected ? '<span class="ok">● Browser connected</span>' : "○ Browser extension not connected";
}

function renderStatus() {
  const c = S.counts;
  $("#s-speed").textContent = "↓ " + (S.speed > 0 ? fmtBytes(S.speed) + "/s" : "0 B/s");
  $("#s-active").textContent = (c.downloading || 0) + " active";
  $("#s-total").textContent = (c.all || 0) + " downloads";
  $("#s-ver").textContent = "NovaDM " + (S.version || "");
  document.title = S.speed > 0 ? "↓ " + fmtBytes(S.speed) + "/s — NovaDM" : "NovaDM";
}

/* ------------------------------------------------------------------ details panel */
const SEG_COLORS = ["#3b82f6", "#22c55e", "#f59e0b", "#a855f7", "#ec4899", "#14b8a6", "#ef4444", "#84cc16"];
async function renderDetails() {
  const box = $("#details");
  const d = S.downloads.find(x => x.id === detailId);
  if (!d || sel.size !== 1) { box.hidden = true; return; }
  box.hidden = false;
  $("#d-name").textContent = d.name;
  const row = (k, v, cls) => { const e = document.createElement("div"); if (cls) e.className = cls; e.append(k + ": "); const b = document.createElement("b"); b.textContent = v; e.appendChild(b); return e; };
  const g = $("#d-grid"); g.textContent = "";
  g.appendChild(row("Status", ST_TXT[d.status]));
  g.appendChild(row("Size", d.size > 0 ? fmtBytes(d.size) : "unknown"));
  g.appendChild(row("Downloaded", fmtBytes(d.done)));
  g.appendChild(row("Resumable", d.resumable ? "Yes" : "No"));
  g.appendChild(row("Connections", d.status === "downloading" ? d.segs_n : (d.resumable ? "up to " + d.conns : 1)));
  g.appendChild(row("Category", d.cat));
  g.appendChild(row("Last try", fmtDate(d.last_try) || "—"));
  g.appendChild(row("Added", fmtDate(d.added)));
  const u = row("Address", d.url); u.classList.add("wide"); g.appendChild(u);
  if (d.path || d.folder) { const p = row("Save to", d.path || d.folder); p.classList.add("wide"); g.appendChild(p); }
  if (d.error) { const e = row("Error", d.error); e.classList.add("wide", "errtxt"); g.appendChild(e); }
  if (d.warn) { const e = row("Note", d.warn); e.classList.add("wide", "warntxt"); g.appendChild(e); }
  let segs = null;
  if (d.size > 0 && d.status !== "completed") { try { segs = await api("segs?id=" + d.id); } catch (e) {} }
  drawSegs(d, segs);
}
function drawSegs(d, data) {
  const c = $("#seg"); const w = c.clientWidth * (window.devicePixelRatio || 1), h = 26 * (window.devicePixelRatio || 1);
  c.width = w; c.height = h;
  const x = c.getContext("2d"); x.clearRect(0, 0, w, h);
  if (d.status === "completed") { x.fillStyle = "#22c55e"; x.fillRect(0, 0, w, h); return; }
  if (!data || !data.size || !data.segs.length) {
    if (d.size > 0) { x.fillStyle = "#3b82f6"; x.fillRect(0, 0, w * d.done / d.size, h); }
    return;
  }
  data.segs.forEach((s, i) => {
    const a = s[0] / data.size * w, filled = Math.max(0, Math.min(s[2], s[1] + 1) - s[0]) / data.size * w;
    x.fillStyle = SEG_COLORS[i % SEG_COLORS.length]; x.globalAlpha = 1; x.fillRect(a, 0, filled, h);
    x.globalAlpha = .18; x.fillRect(a + filled, 0, Math.max(0, (s[1] + 1 - s[0]) / data.size * w - filled), h);
    x.globalAlpha = 1; x.fillStyle = "rgba(0,0,0,.35)"; x.fillRect(a, 0, 1, h);
  });
}

/* ------------------------------------------------------------------ refresh loop */
let busy = false;
async function refresh() {
  if (busy) return; busy = true;
  try {
    const s = await api("state?since=" + S.seq);
    const evs = s.events || [];
    S = Object.assign(S, s); S.seq = Math.max(S.seq, ...evs.map(e => e.seq), s.seq || 0);
    applyTheme(S.settings.theme);
    sel.forEach(id => { if (!S.downloads.some(d => d.id === id)) sel.delete(id); });
    renderNav(); renderList(); renderStatus(); renderDetails();
    evs.forEach(handleEvent);
    updateFfmpegBox();
  } catch (e) { /* app closed or restarting */ }
  busy = false;
}
function handleEvent(e) {
  const open = (what) => () => api("open", {id: e.id, what}).catch(() => {});
  if (e.kind === "complete") toast("Download complete", e.name, "ok", [{label: "Open", fn: open("file"), primary: true}, {label: "Show in folder", fn: open("folder")}], 9000);
  else if (e.kind === "error") toast("Download failed", e.name + (e.error ? " — " + e.error : ""), "err", null, 9000);
  else if (e.kind === "added") toast("Captured from browser", e.name, "", null, 4000);
  else if (e.kind === "clip") toast("Link copied", e.url, "", [
    {label: e.video ? "Download video" : "Download", primary: true, fn: () => e.video ? openVideo(e.url) : openAdd(e.url)},
    {label: "Ignore", fn: () => {}}], 12000);
  else if (e.kind === "after_all") toast("All downloads finished", e.action === "shutdown" ? "The PC will shut down in 60 seconds." : (e.action === "sleep" ? "Putting the PC to sleep…" : "Closing NovaDM…"), "warn",
    e.action === "shutdown" ? [{label: "Cancel shutdown", fn: () => api("cancel_shutdown", {})}] : null, 20000);
}

/* ------------------------------------------------------------------ selection / actions */
const ids = () => Array.from(sel);
function select(idsArr, detail) { sel = new Set(idsArr); detailId = detail || (idsArr.length === 1 ? idsArr[0] : null); renderList(); renderDetails(); }
$("#rows").addEventListener("click", ev => {
  const row = ev.target.closest(".row"); if (!row) return;
  const id = row.dataset.id; const order = $$(".row").map(r => r.dataset.id);
  if (ev.shiftKey && lastClicked) {
    const a = order.indexOf(lastClicked), b = order.indexOf(id);
    select(order.slice(Math.min(a, b), Math.max(a, b) + 1));
  } else if (ev.ctrlKey || ev.metaKey) {
    const n = new Set(sel); n.has(id) ? n.delete(id) : n.add(id); select(Array.from(n)); lastClicked = id;
  } else { select([id]); lastClicked = id; }
});
$("#rows").addEventListener("dblclick", ev => {
  const row = ev.target.closest(".row"); if (!row) return;
  const d = S.downloads.find(x => x.id === row.dataset.id);
  if (d && d.status === "completed") api("open", {id: d.id, what: "file"}).catch(e => toast("Cannot open", e.message, "err"));
});
$("#list").addEventListener("click", ev => { if (ev.target.id === "list" || ev.target.id === "rows") select([]); });
$("#rows").addEventListener("contextmenu", ev => {
  const row = ev.target.closest(".row"); if (!row) return;
  ev.preventDefault();
  if (!sel.has(row.dataset.id)) select([row.dataset.id]);
  showCtx(ev.clientX, ev.clientY);
});
$("#nav-status").addEventListener("click", navClick); $("#nav-cats").addEventListener("click", navClick);
function navClick(ev) { const n = ev.target.closest(".nav-i"); if (!n) return; filt = {type: n.dataset.type, key: n.dataset.key}; lastIds = ""; renderNav(); renderList(); }
$$(".thead [data-sort]").forEach(h => h.addEventListener("click", () => {
  const k = h.dataset.sort; if (sortKey === k) sortDir = -sortDir; else { sortKey = k; sortDir = k === "name" ? 1 : -1; }
  lastIds = ""; renderList();
}));
$("#d-close").onclick = () => select([]);

async function act(action, extra) {
  try { await api("action", Object.assign({action}, extra || {})); await refresh(); } catch (e) { toast("Error", e.message, "err"); }
}
function selDls() { return S.downloads.filter(d => sel.has(d.id)); }
function confirmRemove() {
  const list = selDls(); if (!list.length) return;
  $("#c-title").textContent = "Remove " + list.length + " download" + (list.length > 1 ? "s" : "") + "?";
  $("#c-msg").textContent = list.length === 1 ? list[0].name : "The selected downloads will be removed from the list.";
  $("#c-files").checked = false;
  $("#c-files-l").style.display = list.some(d => d.status === "completed") ? "" : "none";
  $("#c-yes").onclick = () => { $("#dlg-confirm").close(); act("remove", {ids: ids(), delete_files: $("#c-files").checked}); select([]); };
  $("#c-no").onclick = () => $("#dlg-confirm").close();
  $("#dlg-confirm").showModal();
}
$("#b-resume").onclick = () => act("resume", {ids: ids()});
$("#b-pause").onclick = () => act("pause", {ids: ids()});
$("#b-pauseall").onclick = () => act("pause_all");
$("#b-delete").onclick = confirmRemove;

/* ------------------------------------------------------------------ menus */
function placeMenu(m, x, y) {
  m.hidden = false; const r = m.getBoundingClientRect();
  m.style.left = Math.min(x, innerWidth - r.width - 8) + "px"; m.style.top = Math.min(y, innerHeight - r.height - 8) + "px";
}
function fillMenu(m, items) {
  m.textContent = "";
  items.forEach(it => {
    if (it === "-") { m.appendChild(document.createElement("hr")); return; }
    const e = document.createElement("div"); e.className = "mi" + (it.dis ? " dis" : "") + (it.danger ? " danger" : "");
    e.textContent = it.label; e.onclick = () => { m.hidden = true; it.fn(); }; m.appendChild(e);
  });
}
function showCtx(x, y) {
  const l = selDls(); const one = l.length === 1 ? l[0] : null;
  const done = l.length && l.every(d => d.status === "completed");
  fillMenu($("#ctx"), [
    {label: "Open file", dis: !(one && one.status === "completed"), fn: () => api("open", {id: one.id, what: "file"})},
    {label: "Show in folder", dis: !one, fn: () => api("open", {id: one.id, what: "folder"})},
    "-",
    {label: "Resume", dis: !l.some(d => ["paused", "error", "scheduled"].includes(d.status)), fn: () => act("resume", {ids: ids()})},
    {label: "Pause", dis: !l.some(d => ["downloading", "queued", "scheduled"].includes(d.status)), fn: () => act("pause", {ids: ids()})},
    {label: "Download again", dis: !l.length, fn: () => act("redownload", {ids: ids()})},
    "-",
    {label: "Copy address", dis: !one, fn: () => navigator.clipboard.writeText(one.url).then(() => toast("Copied", one.url, "ok", null, 2500))},
    {label: done ? "Remove from list" : "Remove", danger: true, fn: confirmRemove},
  ]);
  placeMenu($("#ctx"), x, y);
}
$("#b-menu").onclick = ev => {
  ev.stopPropagation();
  const b = ev.currentTarget.getBoundingClientRect();
  fillMenu($("#menu"), [
    {label: "Clear completed", fn: () => act("clear_completed")},
    {label: "Install browser extension…", fn: installExt},
    {label: "Install video tools (ffmpeg)…", fn: () => openVideo("")},
    "-",
    {label: "Settings", fn: openSettings},
    {label: "Quit NovaDM", danger: true, fn: quitApp},
  ]);
  placeMenu($("#menu"), b.right - 220, b.bottom + 6);
};
document.addEventListener("click", () => { $("#menu").hidden = true; $("#ctx").hidden = true; });
async function installExt() {
  try { const r = await api("extension/install", {}); toast("Browser extension", "Files copied to " + r.path + ". In Chrome/Edge open chrome://extensions (edge://extensions), turn on Developer mode, click Load unpacked and choose that folder.", "", null, 20000); }
  catch (e) { toast("Error", e.message, "err"); }
}
async function quitApp() { try { await api("quit", {}); } catch (e) {} document.body.innerHTML = '<div style="display:grid;place-content:center;height:100vh;color:#8b95a7;font:16px Segoe UI,sans-serif">NovaDM has been closed. You can close this window.</div>'; }

/* ------------------------------------------------------------------ add dialog */
async function browse(input) {
  try { const r = await api("pick_folder", {initial: input.value}); if (r.path) input.value = r.path; else if (!S.windows) toast("Folder picker", "The folder picker works on Windows. Type a folder path here.", "warn"); }
  catch (e) { toast("Error", e.message, "err"); }
}
function openAdd(url) {
  $("#a-urls").value = url || ""; $("#a-folder").value = ""; $("#a-name").value = ""; $("#a-user").value = ""; $("#a-pass").value = "";
  $("#a-ref").value = ""; $("#a-cookie").value = ""; $("#a-desc").value = ""; $("#a-at").value = ""; $("#a-err").textContent = "";
  $("#a-folder").placeholder = (S.settings.folder || "Default folder") + (S.settings.sort_folders ? "  (+ category folder)" : "");
  const sc = $("#a-conns"); sc.innerHTML = ""; [1, 2, 4, 8, 12, 16, 24, 32].forEach(n => { const o = document.createElement("option"); o.value = n; o.textContent = n; sc.appendChild(o); });
  sc.value = String(S.settings.conns || 8); if (!sc.value) sc.value = "8";
  $$('input[name="a-start"]')[0].checked = true;
  $("#dlg-add").showModal(); $("#a-urls").focus();
}
$("#b-add").onclick = () => openAdd("");
$("#a-browse").onclick = () => browse($("#a-folder"));
$("#a-cancel").onclick = () => $("#dlg-add").close();
$("#a-ok").onclick = async () => {
  const start = $('input[name="a-start"]:checked').value;
  let at = 0;
  if (start === "at") { at = Date.parse($("#a-at").value) / 1000; if (!at || at < Date.now() / 1000) { $("#a-err").textContent = "Choose a time in the future."; return; } }
  try {
    const urls = $("#a-urls").value.split(/\r?\n/).map(s => s.trim()).filter(Boolean);
    const r = await api("add", {urls, folder: $("#a-folder").value.trim(), filename: $("#a-name").value.trim(), conns: +$("#a-conns").value, start, at,
      user: $("#a-user").value, password: $("#a-pass").value, referer: $("#a-ref").value.trim(), cookie: $("#a-cookie").value.trim(), desc: $("#a-desc").value});
    $("#dlg-add").close(); await refresh();
    if (r.ids.length) select([r.ids[0]]);
  } catch (e) { $("#a-err").textContent = e.message; }
};

/* ------------------------------------------------------------------ batch dialog */
let prevT = null;
$("#b-batch").onclick = () => { $("#b-text").value = ""; $("#b-folder").value = ""; $("#b-err").textContent = ""; $("#b-preview").textContent = "0 links"; $("#dlg-batch").showModal(); $("#b-text").focus(); };
$("#b-text").addEventListener("input", () => {
  clearTimeout(prevT);
  prevT = setTimeout(async () => {
    try { const r = await api("preview", {text: $("#b-text").value}); $("#b-preview").textContent = r.count + " link" + (r.count === 1 ? "" : "s") + (r.sample.length ? "\n" + r.sample.join("\n") + (r.count > r.sample.length ? "\n…" : "") : ""); } catch (e) {}
  }, 250);
});
$("#b-browse").onclick = () => browse($("#b-folder"));
$("#b-cancel").onclick = () => $("#dlg-batch").close();
$("#b-ok").onclick = async () => {
  try {
    const urls = $("#b-text").value.split(/\r?\n/).map(s => s.trim()).filter(Boolean);
    const r = await api("add", {urls, folder: $("#b-folder").value.trim(), pattern: true, start: "now"});
    $("#dlg-batch").close(); toast("Added", r.ids.length + " downloads", "ok", null, 3000); refresh();
  } catch (e) { $("#b-err").textContent = e.message; }
};

/* ------------------------------------------------------------------ video dialog */
function openVideo(url) {
  $("#v-url").value = url || ""; $("#v-err").textContent = ""; $("#v-info").hidden = true; $("#v-ok").disabled = true;
  updateFfmpegBox(true); $("#dlg-video").showModal();
  if (url) $("#v-check").click(); else $("#v-url").focus();
}
$("#b-video").onclick = () => openVideo("");
$("#v-cancel").onclick = () => $("#dlg-video").close();
$("#v-check").onclick = async () => {
  const url = $("#v-url").value.trim(); if (!url) return;
  $("#v-err").textContent = ""; $("#v-check").disabled = true; $("#v-check").textContent = "Checking…";
  try {
    const r = await api("video/info", {url});
    $("#v-title").textContent = r.title;
    const m = Math.floor((r.duration || 0) / 60), s = (r.duration || 0) % 60;
    $("#v-meta").textContent = [r.uploader, r.duration ? m + ":" + String(s).padStart(2, "0") : ""].filter(Boolean).join("  •  ");
    const q = $("#v-q"); q.innerHTML = ""; r.options.forEach(o => { const e = document.createElement("option"); e.value = o.id; e.textContent = o.label; q.appendChild(e); });
    $("#v-info").hidden = false; $("#v-ok").disabled = false;
  } catch (e) { $("#v-err").textContent = e.message; }
  $("#v-check").disabled = false; $("#v-check").textContent = "Check";
};
$("#v-ok").onclick = async () => {
  try { await api("video/add", {url: $("#v-url").value.trim(), format: $("#v-q").value}); $("#dlg-video").close(); refresh(); }
  catch (e) { $("#v-err").textContent = e.message; }
};
function updateFfmpegBox(force) {
  const box = $("#v-ff"); const v = S.video || {};
  if (!$("#dlg-video").open && !force) return;
  if (v.ffmpeg) { box.hidden = true; return; }
  box.hidden = false; box.textContent = "";
  const t = document.createElement("span");
  t.textContent = v.ff_busy ? "Installing video tools… " + v.ff_pct + "%" : (v.ff_error ? "Install failed: " + v.ff_error : "Without ffmpeg, video quality is limited (~720p) and MP3 is unavailable.");
  box.appendChild(t);
  if (!v.ff_busy) { const b = document.createElement("button"); b.className = "btn"; b.type = "button"; b.textContent = "Install ffmpeg (~90 MB)"; b.onclick = () => api("ffmpeg/install", {}).then(refresh); box.appendChild(b); }
}

/* ------------------------------------------------------------------ settings */
function openSettings() {
  const s = S.settings;
  $("#s-folder").value = s.folder || ""; $("#s-sort").checked = !!s.sort_folders;
  $("#s-conns").value = s.conns; $("#s-conns-v").textContent = s.conns; $("#s-act").value = s.max_active; $("#s-act-v").textContent = s.max_active;
  $("#s-limit-on").checked = !!s.limit_on; $("#s-limit").value = s.limit_kbps; $("#s-after").value = s.after_all;
  $("#s-sched").checked = !!s.sched_on; $("#s-start").value = s.sched_start || ""; $("#s-stop").value = s.sched_stop || "";
  $("#s-clip").checked = !!s.clip_monitor; $("#s-startup").checked = !!s.startup;
  $("#s-startup-l").style.display = S.windows ? "" : "none";
  $("#dlg-set").showModal();
}
$("#b-settings").onclick = openSettings;
$("#s-conns").oninput = e => $("#s-conns-v").textContent = e.target.value;
$("#s-act").oninput = e => $("#s-act-v").textContent = e.target.value;
$("#s-browse").onclick = () => browse($("#s-folder"));
$("#s-ext").onclick = installExt;
$("#s-cancel").onclick = () => $("#dlg-set").close();
$("#s-ok").onclick = async () => {
  try {
    await api("settings", {folder: $("#s-folder").value.trim(), sort_folders: $("#s-sort").checked, conns: +$("#s-conns").value, max_active: +$("#s-act").value,
      limit_on: $("#s-limit-on").checked, limit_kbps: +$("#s-limit").value || 1024, after_all: $("#s-after").value, sched_on: $("#s-sched").checked,
      sched_start: $("#s-start").value, sched_stop: $("#s-stop").value, clip_monitor: $("#s-clip").checked, startup: $("#s-startup").checked});
    $("#dlg-set").close(); toast("Settings saved", "", "ok", null, 2200); refresh();
  } catch (e) { toast("Error", e.message, "err"); }
};
function applyTheme(t) { document.documentElement.setAttribute("data-theme", t === "light" ? "light" : "dark"); }
$("#b-theme").onclick = async () => { const t = S.settings.theme === "light" ? "dark" : "light"; applyTheme(t); try { await api("settings", {theme: t}); } catch (e) {} refresh(); };

/* ------------------------------------------------------------------ keyboard, paste, drag & drop */
document.addEventListener("keydown", ev => {
  const typing = /^(INPUT|TEXTAREA|SELECT)$/.test((ev.target.tagName || ""));
  if ($$("dialog[open]").length) return;
  if (ev.key === "Delete" && !typing) { confirmRemove(); }
  else if ((ev.ctrlKey || ev.metaKey) && ev.key.toLowerCase() === "n") { ev.preventDefault(); openAdd(""); }
  else if ((ev.ctrlKey || ev.metaKey) && ev.key.toLowerCase() === "a" && !typing) { ev.preventDefault(); select($$(".row").map(r => r.dataset.id)); }
  else if (ev.key === "Enter" && !typing && sel.size === 1) { const d = selDls()[0]; if (d && d.status === "completed") api("open", {id: d.id, what: "file"}); }
});
document.addEventListener("paste", ev => {
  if (/^(INPUT|TEXTAREA)$/.test((ev.target.tagName || "")) || $$("dialog[open]").length) return;
  const t = (ev.clipboardData && ev.clipboardData.getData("text")) || "";
  if (/^https?:\/\//im.test(t)) { ev.preventDefault(); openAdd(t.trim()); }
});
document.addEventListener("dragover", ev => ev.preventDefault());
document.addEventListener("drop", ev => {
  ev.preventDefault();
  const t = ev.dataTransfer.getData("text/uri-list") || ev.dataTransfer.getData("text/plain") || "";
  const lines = t.split(/\r?\n/).filter(l => /^https?:\/\//i.test(l.trim()));
  if (lines.length) openAdd(lines.join("\n")); else toast("Drop a link here", "Drag a download link from your browser into this window.", "warn", null, 3500);
});
window.addEventListener("resize", () => renderDetails());
$$("dialog").forEach(d => d.addEventListener("cancel", () => {}));

refresh(); setInterval(refresh, 800);
window.__novadm = {refresh, openAdd, openVideo, openSettings};
})();
