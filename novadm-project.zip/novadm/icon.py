"""App icon drawn in code (used for the tray icon and the .ico build step)."""


def draw_icon(size=256):
    from PIL import Image, ImageDraw
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    s = size
    d.rounded_rectangle([s * 0.04, s * 0.04, s * 0.96, s * 0.96], radius=s * 0.22, fill=(37, 99, 235, 255))
    d.rounded_rectangle([s * 0.04, s * 0.04, s * 0.96, s * 0.55], radius=s * 0.22, fill=(59, 130, 246, 255))
    d.rectangle([s * 0.04, s * 0.30, s * 0.96, s * 0.56], fill=(59, 130, 246, 255))
    w = s * 0.07
    d.rectangle([s * 0.5 - w, s * 0.2, s * 0.5 + w, s * 0.55], fill="white")
    d.polygon([(s * 0.26, s * 0.5), (s * 0.74, s * 0.5), (s * 0.5, s * 0.76)], fill="white")
    d.rounded_rectangle([s * 0.24, s * 0.80, s * 0.76, s * 0.86], radius=s * 0.03, fill="white")
    return img
