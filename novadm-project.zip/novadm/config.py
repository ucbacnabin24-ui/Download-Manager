"""Paths, settings and file categories."""
import json
import os
import sys
import threading

from . import APP_NAME

CATEGORIES = {
    "Compressed": "zip rar 7z tar gz bz2 xz iso cab zst",
    "Documents": "pdf doc docx xls xlsx ppt pptx txt epub csv rtf odt mobi",
    "Music": "mp3 wav flac aac ogg m4a wma opus",
    "Programs": "exe msi apk dmg deb rpm appimage bat msix jar",
    "Video": "mp4 mkv avi mov wmv flv webm m4v ts mpg mpeg 3gp",
    "Images": "jpg jpeg png gif webp bmp svg tiff ico heic",
}
_EXT_MAP = {e: c for c, v in CATEGORIES.items() for e in v.split()}
ALL_CATEGORIES = list(CATEGORIES.keys()) + ["Other"]


def category_of(filename: str) -> str:
    ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
    return _EXT_MAP.get(ext, "Other")


def data_dir() -> str:
    override = os.environ.get("NOVADM_HOME")
    if override:
        d = override
    else:
        base = os.environ.get("APPDATA") or os.path.join(os.path.expanduser("~"), ".config")
        d = os.path.join(base, APP_NAME)
    os.makedirs(d, exist_ok=True)
    return d


def resource_path(rel: str) -> str:
    base = getattr(sys, "_MEIPASS", None) or os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base, rel)


def default_download_dir() -> str:
    return os.path.join(os.path.expanduser("~"), "Downloads", APP_NAME)


DEFAULTS = {
    "folder": "",                 # empty = ~/Downloads/NovaDM
    "conns": 8,                   # connections per download (1-32)
    "max_active": 3,              # simultaneous downloads
    "limit_on": False,
    "limit_kbps": 1024,           # global speed limit when limit_on
    "clip_monitor": True,
    "startup": False,
    "theme": "dark",
    "after_all": "nothing",       # nothing | close | sleep | shutdown
    "sort_folders": True,         # save into category sub-folders
    "sched_on": False,
    "sched_start": "02:00",
    "sched_stop": "",
    "ext_notice": True,
}


class Settings:
    def __init__(self):
        self.path = os.path.join(data_dir(), "settings.json")
        self.lock = threading.Lock()
        self.data = dict(DEFAULTS)
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                self.data.update({k: v for k, v in json.load(f).items() if k in DEFAULTS})
        except Exception:
            pass

    def get(self, key):
        with self.lock:
            return self.data.get(key, DEFAULTS.get(key))

    def all(self) -> dict:
        with self.lock:
            d = dict(self.data)
        if not d.get("folder"):
            d["folder"] = default_download_dir()
        return d

    def update(self, new: dict):
        with self.lock:
            for k, v in new.items():
                if k not in DEFAULTS:
                    continue
                if isinstance(DEFAULTS[k], bool):
                    v = bool(v)
                elif isinstance(DEFAULTS[k], int):
                    try:
                        v = int(v)
                    except (TypeError, ValueError):
                        continue
                    if k == "conns":
                        v = max(1, min(32, v))
                    elif k == "max_active":
                        v = max(1, min(10, v))
                    elif k == "limit_kbps":
                        v = max(10, min(10_000_000, v))
                else:
                    v = str(v)
                self.data[k] = v
            tmp = self.path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(self.data, f, indent=2)
            os.replace(tmp, self.path)

    def base_folder(self) -> str:
        return self.get("folder") or default_download_dir()
