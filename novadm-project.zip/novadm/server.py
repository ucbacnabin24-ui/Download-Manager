"""Local HTTP server: serves the UI, the JSON API (token protected) and the browser-extension API."""
import hmac
import json
import mimetypes
import os
import secrets
import shutil
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

from . import APP_NAME, APP_VERSION, winutils
from .config import data_dir, resource_path
from .manager import Manager
from .video import ffmpeg_dir, have_ytdlp, video_info

PORTS = list(range(9614, 9624))


class Context:
    def __init__(self, manager: Manager, settings):
        self.manager = manager
        self.settings = settings
        self.token = secrets.token_urlsafe(24)
        self.port = 0
        self.show_cb = None
        self.quit_cb = None
        self.ui_dir = resource_path(os.path.join("novadm", "ui"))
        self.last_poll = time.time()


def _ext_origin_ok(origin: str) -> bool:
    return origin == "" or origin.startswith(("chrome-extension://", "moz-extension://", "edge-extension://"))


class Handler(BaseHTTPRequestHandler):
    server_version = "NovaDM"
    protocol_version = "HTTP/1.0"

    def log_message(self, *a):
        pass

    # ------------------------------------------------------------------ helpers
    @property
    def ctx(self) -> Context:
        return self.server.ctx

    def _send(self, code, body, ctype="application/json", extra=None):
        if not isinstance(body, (bytes, bytearray)):
            body = json.dumps(body).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def _host_ok(self):
        host = self.headers.get("Host", "")
        p = self.ctx.port
        return host in (f"127.0.0.1:{p}", f"localhost:{p}")

    def _api_ok(self):
        tok = self.headers.get("X-Token", "")
        return self._host_ok() and hmac.compare_digest(tok, self.ctx.token)

    def _ext_ok(self):
        h = self.headers
        return (self._host_ok() and (h.get("X-NovaDM") == "1" or h.get("X-PyDM") == "1")
                and _ext_origin_ok(h.get("Origin", "")))

    def _body(self):
        n = int(self.headers.get("Content-Length") or 0)
        if n <= 0:
            return {}
        if n > 2_000_000:
            raise ValueError("request too large")
        return json.loads(self.rfile.read(n).decode("utf-8"))

    # ------------------------------------------------------------------ GET
    def do_GET(self):
        u = urlparse(self.path)
        path = u.path
        q = parse_qs(u.query)
        if path == "/":
            if not self._host_ok() or (q.get("k") or [""])[0] != self.ctx.token:
                return self._send(403, b"Open NovaDM from its own window.", "text/plain")
            try:
                with open(os.path.join(self.ctx.ui_dir, "index.html"), "r", encoding="utf-8") as f:
                    html = f.read().replace("__TOKEN__", self.ctx.token).replace("__VERSION__", APP_VERSION)
            except OSError:
                return self._send(500, b"UI files missing", "text/plain")
            return self._send(200, html.encode("utf-8"), "text/html; charset=utf-8")
        if path.startswith("/static/"):
            if not self._host_ok():
                return self._send(403, {"error": "forbidden"})
            name = os.path.basename(path)
            fp = os.path.join(self.ctx.ui_dir, name)
            if not os.path.isfile(fp) or name == "index.html":
                return self._send(404, {"error": "not found"})
            ctype = mimetypes.guess_type(fp)[0] or "application/octet-stream"
            with open(fp, "rb") as f:
                return self._send(200, f.read(), ctype)
        if path == "/ping":
            if not self._ext_ok():
                return self._send(403, {"ok": False})
            self.ctx.manager.ext_seen = time.time()
            return self._send(200, {"ok": True, "app": APP_NAME, "version": APP_VERSION})
        if path.startswith("/api/"):
            if not self._api_ok():
                return self._send(403, {"error": "forbidden"})
            m = self.ctx.manager
            if path == "/api/state":
                self.ctx.last_poll = time.time()
                since = int((q.get("since") or ["0"])[0] or 0)
                snap = m.snapshot()
                snap["events"] = m.events_since(since)
                snap["settings"] = self.ctx.settings.all()
                ff = ffmpeg_dir()
                snap["video"] = {"ytdlp": have_ytdlp(), "ffmpeg": bool(ff), "ff_busy": m.ffmpeg["busy"],
                                 "ff_pct": m.ffmpeg["pct"], "ff_error": m.ffmpeg["error"]}
                snap["version"] = APP_VERSION
                snap["windows"] = winutils.IS_WIN
                return self._send(200, snap)
            if path == "/api/segs":
                return self._send(200, m.segments((q.get("id") or [""])[0]))
            return self._send(404, {"error": "not found"})
        self._send(404, {"error": "not found"})

    # ------------------------------------------------------------------ POST
    def do_POST(self):
        path = urlparse(self.path).path
        try:
            if path in ("/add", "/show"):
                if not self._ext_ok():
                    return self._send(403, {"ok": False})
                if path == "/show":
                    if self.ctx.show_cb:
                        threading.Thread(target=self.ctx.show_cb, daemon=True).start()
                    return self._send(200, {"ok": True})
                ids = self.ctx.manager.add_from_extension(self._body())
                return self._send(200, {"ok": True, "ids": ids})
            if not path.startswith("/api/"):
                return self._send(404, {"error": "not found"})
            if not self._api_ok() or "application/json" not in self.headers.get("Content-Type", ""):
                return self._send(403, {"error": "forbidden"})
            self._api_post(path[5:], self._body())
        except ValueError as e:
            self._send(400, {"error": str(e)})
        except Exception as e:  # noqa
            self._send(500, {"error": (str(e) or e.__class__.__name__)[:300]})

    def _api_post(self, route, b):
        m = self.ctx.manager
        s = self.ctx.settings
        if route == "add":
            at = float(b.get("at") or 0)
            ids = m.add_urls(b.get("urls") or [b.get("url", "")], folder=str(b.get("folder", "")),
                             filename=str(b.get("filename", "")), conns=b.get("conns"), start=str(b.get("start", "now")),
                             at=at, user=str(b.get("user", "")), password=str(b.get("password", "")),
                             referer=str(b.get("referer", "")), cookie=str(b.get("cookie", "")), desc=str(b.get("desc", "")),
                             pattern=bool(b.get("pattern")))
            return self._send(200, {"ok": True, "ids": ids})
        if route == "preview":
            from .engine import expand_pattern
            urls = []
            for line in str(b.get("text", "")).splitlines():
                if line.strip():
                    urls.extend(expand_pattern(line.strip(), 2000))
            return self._send(200, {"count": len(urls), "sample": urls[:6]})
        if route == "video/info":
            if not have_ytdlp():
                raise ValueError("The video engine (yt-dlp) is not installed in this build.")
            return self._send(200, video_info(str(b.get("url", "")), str(b.get("cookie", ""))))
        if route == "video/add":
            ids = m.add_video(str(b.get("url", "")), str(b.get("format", "best")), folder=str(b.get("folder", "")))
            return self._send(200, {"ok": True, "ids": ids})
        if route == "action":
            act = b.get("action")
            ids = [str(i) for i in (b.get("ids") or [])]
            if act == "pause":
                m.pause(ids)
            elif act == "resume":
                m.resume(ids)
            elif act == "remove":
                m.remove(ids, bool(b.get("delete_files")))
            elif act == "redownload":
                m.redownload(ids)
            elif act == "pause_all":
                m.pause_all()
            elif act == "resume_all":
                m.resume_all()
            elif act == "clear_completed":
                m.clear_completed()
            else:
                raise ValueError("unknown action")
            return self._send(200, {"ok": True})
        if route == "settings":
            before = s.get("startup")
            s.update(b)
            m.apply_limits()
            if s.get("startup") != before:
                winutils.set_startup(bool(s.get("startup")))
            return self._send(200, {"ok": True, "settings": s.all()})
        if route == "pick_folder":
            return self._send(200, {"path": winutils.pick_folder(str(b.get("initial", "")))})
        if route == "open":
            d = m.get(str(b.get("id", "")))
            if not d:
                raise ValueError("download not found")
            target = d.path if os.path.exists(d.path or "") else (d.part_path if os.path.exists(d.part_path) else d.folder)
            if b.get("what") == "folder" or not (d.path and os.path.exists(d.path)):
                winutils.reveal(target)
            else:
                winutils.open_path(d.path)
            return self._send(200, {"ok": True})
        if route == "ffmpeg/install":
            m.install_ffmpeg()
            return self._send(200, {"ok": True})
        if route == "extension/install":
            dst = os.path.join(data_dir(), "browser-extension")
            src = resource_path("extension")
            if not os.path.isdir(src):
                raise ValueError("The extension files are missing from this build.")
            shutil.copytree(src, dst, dirs_exist_ok=True)
            winutils.open_path(dst)
            return self._send(200, {"ok": True, "path": dst})
        if route == "cancel_shutdown":
            winutils.cancel_shutdown()
            return self._send(200, {"ok": True})
        if route == "quit":
            self._send(200, {"ok": True})
            if self.ctx.quit_cb:
                threading.Thread(target=self.ctx.quit_cb, daemon=True).start()
            return
        raise ValueError("unknown route")


def serve(ctx: Context, preferred=None):
    ports = [preferred] if preferred else PORTS
    srv = None
    for p in ports:
        try:
            srv = ThreadingHTTPServer(("127.0.0.1", p), Handler)
            break
        except OSError:
            continue
    if srv is None:
        srv = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    srv.daemon_threads = True
    srv.ctx = ctx
    ctx.port = srv.server_address[1]
    threading.Thread(target=srv.serve_forever, daemon=True, name="http").start()
    return srv
