NovaDM browser extension
========================
Chrome / Edge / Brave:  chrome://extensions  ->  Developer mode ON  ->  Load unpacked  ->  pick this folder.
Firefox: about:debugging -> This Firefox -> Load Temporary Add-on -> manifest.json
NovaDM must be running (it can sit in the tray).
