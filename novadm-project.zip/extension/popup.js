const api = globalThis.browser ?? globalThis.chrome;
const $ = id => document.getElementById(id);

(async () => {
  const s = await api.storage.local.get({ enabled: true, showButton: true, quality: "best", minKB: 0 });
  $("enabled").checked = s.enabled;
  $("showButton").checked = s.showButton;
  $("quality").value = s.quality;
  $("minKB").value = s.minKB;
  let r = null;
  try { r = await api.runtime.sendMessage({ type: "ping" }); } catch {}
  $("status").textContent = r && r.ok ? "\u25CF NovaDM connected" : "\u25CF NovaDM is not running";
  $("status").className = r && r.ok ? "ok" : "off";
})();

$("enabled").onchange = e => api.storage.local.set({ enabled: e.target.checked });
$("showButton").onchange = e => api.storage.local.set({ showButton: e.target.checked });
$("quality").onchange = e => api.storage.local.set({ quality: e.target.value });
$("minKB").onchange = e => api.storage.local.set({ minKB: Math.max(0, parseInt(e.target.value || "0", 10) || 0) });

$("grab").onclick = async () => {
  const [tab] = await api.tabs.query({ active: true, currentWindow: true });
  let r = null;
  try { r = await api.runtime.sendMessage({ type: "video", url: tab.url }); } catch {}
  $("msg").textContent = r && r.ok ? "Sent to NovaDM \u2713" : "Failed - is NovaDM open?";
};
$("show").onclick = async () => {
  try { await api.runtime.sendMessage({ type: "show" }); } catch {}
  window.close();
};
