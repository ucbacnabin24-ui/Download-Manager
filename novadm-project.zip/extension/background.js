const api = globalThis.browser ?? globalThis.chrome;
const PORTS = [9614, 9615, 9616, 9617, 9618, 9619, 9620, 9621, 9622, 9623];
const HDR = { "X-NovaDM": "1", "Content-Type": "application/json" };
const DEFAULTS = { enabled: true, showButton: true, quality: "best", minKB: 0 };
const getSettings = () => api.storage.local.get(DEFAULTS);
let cachedPort = null;

async function pingPort(p) {
  const r = await fetch(`http://127.0.0.1:${p}/ping`, { headers: HDR, signal: AbortSignal.timeout(900) });
  if (!r.ok) throw new Error("no");
  const j = await r.json();
  if (j.app !== "NovaDM") throw new Error("other");
  return p;
}

async function findPort() {
  if (cachedPort) {
    try { return await pingPort(cachedPort); } catch { cachedPort = null; }
  }
  try { cachedPort = await Promise.any(PORTS.map(pingPort)); return cachedPort; } catch { return null; }
}

async function post(path, payload) {
  const port = await findPort();
  if (!port) return false;
  try {
    const r = await fetch(`http://127.0.0.1:${port}${path}`, {
      method: "POST", headers: HDR, body: JSON.stringify(payload || {}), signal: AbortSignal.timeout(5000)
    });
    return r.ok;
  } catch { return false; }
}

async function cookieHeader(url) {
  try {
    const list = await api.cookies.getAll({ url });
    return list.map(c => `${c.name}=${c.value}`).join("; ");
  } catch { return ""; }
}

function badge(text, color) {
  try {
    api.action.setBadgeBackgroundColor({ color });
    api.action.setBadgeText({ text });
    setTimeout(() => api.action.setBadgeText({ text: "" }), 2500);
  } catch {}
}

async function sendFile(url, referer = "") {
  if (!/^https?:/i.test(url || "")) return false;
  const ok = await post("/add", { url, referer, cookie: await cookieHeader(url), ua: navigator.userAgent });
  badge(ok ? "OK" : "OFF", ok ? "#16a34a" : "#dc2626");
  return ok;
}

async function sendVideo(url) {
  if (!/^https?:/i.test(url || "")) return false;
  const { quality } = await getSettings();
  const ok = await post("/add", { url, video: true, quality });
  badge(ok ? "OK" : "OFF", ok ? "#16a34a" : "#dc2626");
  return ok;
}

// 1) capture normal browser downloads while NovaDM is running
api.downloads.onCreated.addListener(async (item) => {
  try {
    if (item.byExtensionId) return;
    const s = await getSettings();
    if (!s.enabled) return;
    const url = item.finalUrl || item.url;
    if (!/^https?:/i.test(url || "")) return;
    const size = item.fileSize > 0 ? item.fileSize : item.totalBytes;
    if (s.minKB > 0 && size > 0 && size < s.minKB * 1024) return;
    if (!(await findPort())) return;                 // NovaDM closed -> the browser downloads normally
    const ok = await post("/add", { url, referer: item.referrer || "", cookie: await cookieHeader(url), ua: navigator.userAgent });
    if (ok) {
      try { await api.downloads.cancel(item.id); } catch {}
      try { await api.downloads.erase({ id: item.id }); } catch {}
      badge("OK", "#16a34a");
    }
  } catch {}
});

// 2) right-click menu
api.runtime.onInstalled.addListener(() => {
  api.contextMenus.removeAll(() => {
    api.contextMenus.create({ id: "nd-link", title: "Download link with NovaDM", contexts: ["link"] });
    api.contextMenus.create({ id: "nd-media", title: "Download this media with NovaDM", contexts: ["image", "video", "audio"] });
    api.contextMenus.create({ id: "nd-video", title: "Grab video with NovaDM (YouTube etc.)", contexts: ["page", "link"] });
  });
});
api.contextMenus.onClicked.addListener((info) => {
  if (info.menuItemId === "nd-link") sendFile(info.linkUrl, info.pageUrl);
  else if (info.menuItemId === "nd-media") {
    if (/^https?:/i.test(info.srcUrl || "")) sendFile(info.srcUrl, info.pageUrl); else sendVideo(info.pageUrl);
  } else if (info.menuItemId === "nd-video") sendVideo(info.linkUrl || info.pageUrl);
});

// 3) messages from the popup / page button
api.runtime.onMessage.addListener((msg, _s, reply) => {
  (async () => {
    if (msg.type === "video") reply({ ok: await sendVideo(msg.url) });
    else if (msg.type === "ping") reply({ ok: !!(await findPort()) });
    else if (msg.type === "show") reply({ ok: await post("/show", {}) });
    else reply({ ok: false });
  })();
  return true;
});
