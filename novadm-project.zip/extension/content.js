(() => {
  const api = globalThis.browser ?? globalThis.chrome;
  let btn = null, show = true;
  api.storage.local.get({ showButton: true }).then(s => { show = s.showButton; }).catch(() => {});
  api.storage.onChanged.addListener(c => { if (c.showButton) show = c.showButton.newValue; });

  function hasVideo() {
    const h = location.hostname, p = location.pathname;
    if (/(^|\.)youtube\.com$/.test(h)) return p === "/watch" || p.startsWith("/shorts/") || p.startsWith("/live/");
    if (h === "youtu.be") return true;
    return !!document.querySelector("video");
  }

  function make() {
    const b = document.createElement("button");
    b.textContent = "\u2B07 NovaDM";
    b.title = "Download this video with NovaDM";
    Object.assign(b.style, {
      position: "fixed", right: "16px", bottom: "90px", zIndex: 2147483647,
      padding: "8px 14px", background: "#2563eb", color: "#fff", border: "none",
      borderRadius: "20px", font: "600 13px system-ui,sans-serif", cursor: "pointer",
      boxShadow: "0 2px 8px rgba(0,0,0,.4)"
    });
    b.addEventListener("click", async (e) => {
      e.stopPropagation();
      b.textContent = "...";
      let ok = false;
      try { ok = (await api.runtime.sendMessage({ type: "video", url: location.href }))?.ok; } catch {}
      b.textContent = ok ? "\u2713 Sent to NovaDM" : "NovaDM not running";
      setTimeout(() => { b.textContent = "\u2B07 NovaDM"; }, 2200);
    });
    document.documentElement.appendChild(b);
    return b;
  }

  setInterval(() => {
    if (btn && !btn.isConnected) btn = null;
    const want = show && hasVideo();
    if (want && !btn) btn = make();
    if (btn) btn.style.display = want ? "block" : "none";
  }, 1500);
})();
