"""NovaDM - fast download manager.  Entry point."""
import argparse
import json
import logging
import os
import sys
import threading
import time
import urllib.request


def _quiet_std():
    for name in ("stdout", "stderr"):
        if getattr(sys, name, None) is None:
            setattr(sys, name, open(os.devnull, "w"))


def handoff() -> bool:
    """If NovaDM is already running, ask it to show its window and exit."""
    from novadm.server import PORTS
    for port in PORTS:
        try:
            req = urllib.request.Request(f"http://127.0.0.1:{port}/ping", headers={"X-NovaDM": "1"})
            with urllib.request.urlopen(req, timeout=0.6) as r:
                info = json.loads(r.read().decode("utf-8"))
            if info.get("app") == "NovaDM":
                req = urllib.request.Request(f"http://127.0.0.1:{port}/show", data=b"{}", method="POST",
                                             headers={"X-NovaDM": "1", "Content-Type": "application/json"})
                urllib.request.urlopen(req, timeout=2).read()
                return True
        except Exception:
            continue
    return False


def main(argv=None):
    _quiet_std()
    ap = argparse.ArgumentParser()
    ap.add_argument("--tray", action="store_true", help="start hidden in the tray")
    ap.add_argument("--no-window", action="store_true", help="(testing) do not open a window or tray")
    ap.add_argument("--port", type=int, default=0)
    args = ap.parse_args(argv)

    from novadm import winutils
    from novadm.config import Settings, data_dir
    from novadm.manager import Manager
    from novadm.server import Context, serve
    from novadm.tray import start_tray

    logging.basicConfig(filename=os.path.join(data_dir(), "novadm.log"), level=logging.INFO,
                        format="%(asctime)s %(levelname)s %(message)s")
    if not args.port and handoff():
        return 0

    settings = Settings()
    mgr = Manager(settings)
    ctx = Context(mgr, settings)
    quit_evt = threading.Event()
    tray = {"icon": None}

    def url():
        return f"http://127.0.0.1:{ctx.port}/?k={ctx.token}"

    def show():
        winutils.open_app_window(url(), os.path.join(data_dir(), "window"))

    def quit_app():
        quit_evt.set()

    ctx.show_cb = show
    ctx.quit_cb = quit_app
    mgr.quit_cb = quit_app
    server = serve(ctx, args.port or None)
    mgr.start()
    logging.info("started on port %s", ctx.port)

    if not args.no_window:
        tray["icon"] = start_tray(show, mgr.pause_all, mgr.resume_all, quit_app)
        if tray["icon"] is not None:
            mgr.notify = lambda title, msg: _notify(tray["icon"], title, msg)
        if not args.tray or tray["icon"] is None:
            show()
    else:
        print(url(), flush=True)

    if not args.no_window:
        # without a tray icon there is no other way to quit: close NovaDM when the window is gone and nothing is downloading
        while not quit_evt.wait(5):
            if tray["icon"] is None and time.time() - ctx.last_poll > 180:
                with mgr.lock:
                    busy = any(d.status in ("downloading", "queued", "scheduled") for d in mgr.downloads.values())
                if not busy:
                    break
    else:
        quit_evt.wait()
    try:
        mgr.shutdown()
        server.shutdown()
        if tray["icon"] is not None:
            tray["icon"].stop()
    finally:
        os._exit(0)


def _notify(icon, title, msg):
    try:
        icon.notify(msg, title)
    except Exception:
        pass


if __name__ == "__main__":
    sys.exit(main())
